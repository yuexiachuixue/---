"""
monitor.py  —  训练进度实时监控
=================================
功能：
  1. 控制台进度条（tqdm）：显示 batch 级别进度 + 实时 loss/lr
  2. GPU/CPU 资源监控：显存占用、利用率（每 epoch 打印一次）
  3. ETA 估计：根据当前耗时预测剩余时间
  4. 训练曲线自动保存：训练结束后输出 loss/RMSE 曲线图（PNG）
  5. 终端摘要表：每 epoch 结束后打印对齐的摘要行

依赖：
  pip install tqdm matplotlib
  （GPU 监控可选：pip install gputil）
"""

import json
import time
import logging
from pathlib import Path
from typing import Optional, Union

import torch

logger = logging.getLogger(__name__)

# ── tqdm（进度条）──────────────────────────────────────────────────────────
try:
    from tqdm import tqdm
    HAS_TQDM = True
except ImportError:
    HAS_TQDM = False
    logger.warning("[Monitor] tqdm 未安装，将使用简单日志替代。pip install tqdm")

# ── matplotlib（曲线图）───────────────────────────────────────────────────
try:
    import matplotlib
    matplotlib.use("Agg")          # 非交互后端，服务器/无 GUI 环境兼容
    import matplotlib.pyplot as plt
    HAS_MPL = True
except ImportError:
    HAS_MPL = False
    logger.warning("[Monitor] matplotlib 未安装，跳过曲线图。pip install matplotlib")

# ── GPUtil（GPU 监控）─────────────────────────────────────────────────────
try:
    import GPUtil
    HAS_GPUTIL = True
except ImportError:
    HAS_GPUTIL = False


# ============================================================================
#  GPU 信息查询（优先 torch，备用 GPUtil）
# ============================================================================

def get_gpu_stats() -> dict:
    """返回当前 GPU 显存（MB）和利用率（%）。无 GPU 则返回空字典。"""
    if not torch.cuda.is_available():
        return {}
    stats = {}
    try:
        mem_alloc = torch.cuda.memory_allocated() / 1024**2
        mem_total = torch.cuda.get_device_properties(0).total_memory / 1024**2
        stats["mem_used_MB"]  = round(mem_alloc, 1)
        stats["mem_total_MB"] = round(mem_total, 1)
        stats["mem_pct"]      = round(mem_alloc / mem_total * 100, 1)
    except Exception:
        pass

    if HAS_GPUTIL:
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                stats["gpu_util_pct"] = gpus[0].load * 100
        except Exception:
            pass
    return stats


def fmt_gpu(stats: dict) -> str:
    """将 GPU 统计格式化为一行字符串。"""
    if not stats:
        return ""
    s = f"GPU mem={stats.get('mem_used_MB', '?')}/{stats.get('mem_total_MB', '?')}MB" \
        f"({stats.get('mem_pct', '?')}%)"
    if "gpu_util_pct" in stats:
        s += f" util={stats['gpu_util_pct']:.0f}%"
    return s


# ============================================================================
#  ETA 计算器
# ============================================================================

class ETAEstimator:
    """根据已完成的 epoch 数线性估算剩余时间。"""

    def __init__(self, total_epochs: int):
        self.total   = total_epochs
        self.t_start = time.time()
        self.times   = []          # 每个 epoch 的耗时（秒）

    def update(self, epoch_time: float):
        self.times.append(epoch_time)

    def eta_str(self, current_epoch: int) -> str:
        if not self.times:
            return "N/A"
        avg_t  = sum(self.times) / len(self.times)
        remain = (self.total - current_epoch) * avg_t
        h, r   = divmod(int(remain), 3600)
        m, s   = divmod(r, 60)
        elapsed_total = time.time() - self.t_start
        eh, er = divmod(int(elapsed_total), 3600)
        em, es = divmod(er, 60)
        return (
            f"ETA {h:02d}:{m:02d}:{s:02d}  "
            f"(已用 {eh:02d}:{em:02d}:{es:02d})"
        )


# ============================================================================
#  主监控类
# ============================================================================

class TrainingMonitor:
    """
    训练监控器，贯穿整个训练生命周期。

    用法：
        monitor = TrainingMonitor(total_epochs=100, save_dir="checkpoints", model_name="fdanet")
        for epoch in range(1, 101):
            pbar = monitor.start_epoch(epoch, n_batches)
            for batch_idx, ... in enumerate(loader):
                ...（forward / backward）...
                monitor.update_batch(pbar, loss_dict, lr)
            monitor.end_epoch(epoch, train_stats, val_metrics, epoch_time)
        monitor.finish(history)
    """

    def __init__(
        self,
        total_epochs: int,
        save_dir: Union[str, Path] = "checkpoints",
        model_name: str = "model",
        print_interval: int = 5,
    ):
        self.total_epochs   = total_epochs
        self.save_dir       = Path(save_dir)
        self.model_name     = model_name
        self.print_interval = print_interval
        self.eta            = ETAEstimator(total_epochs)
        self._header_printed = False

        # 每 epoch 数据持久化文件（JSON Lines 格式，每行一条记录）
        self.history_file = self.save_dir / f"{model_name}_history.jsonl"

    def append_epoch(
        self,
        epoch: int,
        train_stats: dict,
        val_metrics: dict,
        epoch_time: float,
        extra: Optional[dict] = None,
    ):
        """
        将当前 epoch 的数据追加写入 history 文件（原子写入）。
        每行一个 JSON 对象，中断后重启续训时已有记录不会丢失。
        extra 用于传入 GAN 的 D_loss 等额外字段。
        """
        record = {
            "epoch":      epoch,
            "train_loss": train_stats.get("total", float("nan")),
            "G_loss":     train_stats.get("G_total", float("nan")),
            "val_rmse":   val_metrics.get("rmse",  float("nan")),
            "val_mae":    val_metrics.get("mae",   float("nan")),
            "time":       round(epoch_time, 2),
        }
        if extra:
            record.update(extra)
        # 追加写入，不覆盖已有记录
        with open(self.history_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def load_history(self) -> dict:
        """从 history 文件读取所有 epoch 记录，返回包含真实 epoch 编号的 dict。"""
        result: dict = {"epochs": [], "train_loss": [], "val_rmse": [], "val_mae": []}
        if not self.history_file.exists():
            return result
        # 用 dict 去重：同一 epoch 保留最后一条（续训时最新的数据最完整）
        seen_epochs: dict = {}
        with open(self.history_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                    ep = rec.get("epoch", -1)
                    seen_epochs[ep] = rec   # 后来的覆盖前面的
                except json.JSONDecodeError:
                    continue
        rows = sorted(seen_epochs.values(), key=lambda r: r["epoch"])
        for r in rows:
            result["epochs"].append(r["epoch"])
            result["train_loss"].append(r.get("train_loss", float("nan")))
            result["val_rmse"].append(r.get("val_rmse",   float("nan")))
            result["val_mae"].append(r.get("val_mae",    float("nan")))
        # GAN 专用字段（可选）
        if any("G_loss" in r for r in rows):
            result["G_loss"] = [r.get("G_loss", float("nan")) for r in rows]
        if any("D_loss" in r for r in rows):
            result["D_loss"] = [r.get("D_loss", float("nan")) for r in rows]
        return result

    # ── Epoch 级别 ───────────────────────────────────────────────────────

    def start_epoch(self, epoch: int, n_batches: int):
        """
        开启一个 epoch 的进度条（或日志占位）。
        返回 pbar 对象（可能为 None）供 update_batch 使用。
        """
        desc = f"[{self.model_name}] Epoch {epoch:>3}/{self.total_epochs}"
        if HAS_TQDM:
            pbar = tqdm(
                total=n_batches,
                desc=desc,
                unit="batch",
                dynamic_ncols=True,
                leave=False,          # epoch 结束后清除进度条，保持终端整洁
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining} {rate_fmt}] {postfix}",
            )
        else:
            logger.info(f"{desc} — {n_batches} batches")
            pbar = None
        return pbar

    def update_batch(self, pbar, loss_dict: dict, lr: float, batch_idx: int = 0):
        """每个 batch 后调用，刷新进度条或打印日志。"""
        postfix = {
            "loss": f"{loss_dict.get('total', 0):.4f}",
            "pix":  f"{loss_dict.get('pixel', 0):.4f}",
            "lr":   f"{lr:.1e}",
        }
        if "freq" in loss_dict:
            postfix["freq"] = f"{loss_dict['freq']:.4f}"
        if "grad" in loss_dict:
            postfix["grad"] = f"{loss_dict['grad']:.4f}"

        if HAS_TQDM and pbar is not None:
            pbar.set_postfix(postfix, refresh=False)
            pbar.update(1)
        elif batch_idx % self.print_interval == 0:
            parts = "  ".join(f"{k}={v}" for k, v in postfix.items())
            logger.info(f"  batch {batch_idx}  {parts}")

    def close_pbar(self, pbar):
        """关闭当前 epoch 的进度条。"""
        if HAS_TQDM and pbar is not None:
            pbar.close()

    def end_epoch(
        self,
        epoch: int,
        train_stats: dict,
        val_metrics: dict,
        epoch_time: float,
        extra: Optional[dict] = None,   # 额外字段（如 GAN 的 D_loss）
    ):
        """
        epoch 结束时调用：
          - 更新 ETA
          - 打印摘要行（含 GPU 信息）
        """
        self.eta.update(epoch_time)
        gpu_str = fmt_gpu(get_gpu_stats())
        eta_str = self.eta.eta_str(epoch)

        # ── 表头（只打印一次）──────────────────────────────────────────
        if not self._header_printed:
            header = (
                f"{'Epoch':>6} | {'TrainLoss':>9} | {'ValRMSE':>7} | "
                f"{'ValMAE':>7} | {'RSRP_err':>8} | {'Time':>6} | ETA / GPU"
            )
            sep = "-" * len(header)
            logger.info(sep)
            logger.info(header)
            logger.info(sep)
            self._header_printed = True

        # ── 摘要行 ─────────────────────────────────────────────────────
        rmse    = val_metrics.get("rmse", float("nan"))
        mae     = val_metrics.get("mae",  float("nan"))
        rsrp_db = val_metrics.get("rsrp_mae_db", float("nan"))
        t_loss  = train_stats.get("total", train_stats.get("G_total", float("nan")))

        extra_str = ""
        if extra:
            extra_str = "  " + "  ".join(f"{k}={v:.4f}" for k, v in extra.items())

        line = (
            f"{epoch:>6}/{self.total_epochs} | "
            f"{t_loss:>9.4f} | "
            f"{rmse:>7.4f} | "
            f"{mae:>7.4f} | "
            f"{rsrp_db:>7.2f}dB | "
            f"{epoch_time:>5.1f}s | "
            f"{eta_str}"
        )
        if gpu_str:
            line += f"  [{gpu_str}]"
        if extra_str:
            line += extra_str

        logger.info(line)

    # ── 训练结束 ─────────────────────────────────────────────────────────

    def finish(self, history: dict, interrupted: bool = False):
        """训练完成（或中断）后调用，保存训练曲线图。"""
        logger.info("=" * 70)
        if interrupted:
            logger.info(f"[Monitor] 训练已中断，尝试保存已有曲线图...")
        else:
            logger.info(f"[Monitor] 训练完成！正在生成训练曲线图...")
        # 优先从持久化文件读取（包含中断前所有 epoch），内存 history 作为兜底
        file_history = self.load_history()
        if any(len(v) > 0 for v in file_history.values()):
            self._plot_curves(file_history, use_real_epochs=True)
        else:
            self._plot_curves(history, use_real_epochs=False)

    def _plot_curves(self, history: dict, use_real_epochs: bool = False):
        """将 loss / RMSE 曲线保存为 PNG 图片。"""
        if not HAS_MPL:
            logger.warning("[Monitor] matplotlib 不可用，跳过曲线图。")
            return

        # history 为空或所有列表都为空时直接跳过，不报错
        if not history or all(len(v) == 0 for v in history.values()):
            logger.info("[Monitor] 暂无训练记录，跳过曲线图。")
            return

        try:
            # use_real_epochs=True 时用文件里记录的真实 epoch 编号作为 x 轴
            # 这样续训时 x 轴从断点处接续，而不是从 1 重新开始
            if use_real_epochs and "epochs" in history and len(history["epochs"]) > 0:
                epochs = history["epochs"]
            else:
                epochs = list(range(1, len(history.get("train_loss", history.get("G_loss", []))) + 1))
            import math
            def _has_data(lst):
                """列表非空且至少有一个非 NaN 值。"""
                return len(lst) > 0 and any(not (isinstance(v, float) and math.isnan(v)) for v in lst)

            n_plots  = sum(1 for k in ["train_loss", "G_loss", "val_rmse", "val_mae"] if k in history and _has_data(history[k]))
            if n_plots == 0:
                return

            fig, axes = plt.subplots(1, n_plots, figsize=(5 * n_plots, 4))
            if n_plots == 1:
                axes = [axes]

            def _plot(ax, xs, ys, **kwargs):
                """折线图，自动跳过 NaN 点（中断 epoch 的 val 数据）。单点用散点显示。"""
                valid = [(x, y) for x, y in zip(xs, ys) if not (isinstance(y, float) and math.isnan(y))]
                if not valid:
                    return
                vx, vy = zip(*valid)
                if len(vx) == 1:
                    ax.scatter(vx, vy, s=60, zorder=5, color=kwargs.get("color", "steelblue"),
                               label=kwargs.get("label", ""))
                    ax.annotate(f"{vy[0]:.4f}", (vx[0], vy[0]),
                                textcoords="offset points", xytext=(6, 4), fontsize=8)
                else:
                    ax.plot(vx, vy, **kwargs)

            def _fix_xaxis(ax, xs):
                """强制 x 轴显示整数刻度，epoch 数多时自动稀疏，避免标签拥挤。"""
                if len(xs) > 20:
                    step = max(1, len(xs) // 10)
                    ticks = xs[::step]
                    if xs[-1] not in ticks:
                        ticks = list(ticks) + [xs[-1]]
                    ax.set_xticks(ticks)
                else:
                    ax.set_xticks(xs)
                ax.set_xlim(xs[0] - 0.5, xs[-1] + 0.5)

            ax_idx = 0

            # ── Loss 曲线 ─────────────────────────────────────────────
            if "train_loss" in history and _has_data(history["train_loss"]):
                ax = axes[ax_idx]; ax_idx += 1
                _plot(ax, epochs, history["train_loss"], color="steelblue", linewidth=1.5, label="Train Loss")
                _fix_xaxis(ax, epochs)
                ax.set_title("Training Loss"); ax.set_xlabel("Epoch"); ax.set_ylabel("Loss")
                ax.legend(); ax.grid(alpha=0.3)

            if "G_loss" in history and _has_data(history["G_loss"]):    # GAN
                ax = axes[ax_idx]; ax_idx += 1
                _plot(ax, epochs, history["G_loss"], color="steelblue", linewidth=1.5, label="G Loss")
                if "D_loss" in history and len(history["D_loss"]) > 0:
                    _plot(ax, epochs, history["D_loss"], color="tomato", linewidth=1.5, label="D Loss")
                _fix_xaxis(ax, epochs)
                ax.set_title("GAN Loss"); ax.set_xlabel("Epoch"); ax.set_ylabel("Loss")
                ax.legend(); ax.grid(alpha=0.3)

            # ── RMSE 曲线 ─────────────────────────────────────────────
            if "val_rmse" in history and _has_data(history["val_rmse"]):
                ax = axes[ax_idx]; ax_idx += 1
                valid_rmse = [v for v in history["val_rmse"] if not (isinstance(v, float) and math.isnan(v))]
                _plot(ax, epochs, history["val_rmse"], color="darkorange", linewidth=1.5, label="Val RMSE")
                if valid_rmse:
                    best_val   = min(valid_rmse)
                    best_idx   = history["val_rmse"].index(best_val)
                    # 用真实 epoch 编号定位竖线，而非列表下标
                    best_epoch = epochs[best_idx]
                    ax.axvline(best_epoch, color="gray", linestyle="--", linewidth=1, label=f"Best@{best_epoch}")
                    ax.set_title(f"Val RMSE  (best={best_val:.4f} @ep{best_epoch})")
                else:
                    ax.set_title("Val RMSE")
                _fix_xaxis(ax, epochs)
                ax.set_xlabel("Epoch"); ax.set_ylabel("RMSE")
                ax.legend(); ax.grid(alpha=0.3)

            # ── MAE 曲线 ──────────────────────────────────────────────
            if "val_mae" in history and _has_data(history["val_mae"]):
                ax = axes[ax_idx]; ax_idx += 1
                _plot(ax, epochs, history["val_mae"], color="mediumseagreen", linewidth=1.5, label="Val MAE")
                _fix_xaxis(ax, epochs)
                ax.set_title("Val MAE"); ax.set_xlabel("Epoch"); ax.set_ylabel("MAE")
                ax.legend(); ax.grid(alpha=0.3)

            plt.suptitle(f"{self.model_name} Training Curves", fontsize=13, y=1.02)
            plt.tight_layout()

            out_path = self.save_dir / f"{self.model_name}_training_curves.png"
            plt.savefig(out_path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            logger.info(f"[Monitor] 曲线图已保存 → {out_path}")

        except Exception as e:
            logger.warning(f"[Monitor] 绘图失败：{e}")
