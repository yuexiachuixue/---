"""
app.py  —  无线电地图估计 Web 演示（Flask）
=============================================
使用方式：
  pip install flask
  python app.py

然后浏览器访问 http://localhost:5000
"""

import sys
import io
import math
import base64
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from flask import Flask, render_template, request, jsonify

CODE_DIR = Path(__file__).parent
sys.path.insert(0, str(CODE_DIR))

from models import build_model  # noqa: E402

# ============================================================================
#  配置
# ============================================================================

CKPT_DIR    = Path(r".\checkpoints")
DEVICE      = torch.device("cuda" if torch.cuda.is_available() else "cpu")
IMG_SIZE    = 256
RSRP_MIN    = -150.0
RSRP_MAX    =    0.0
MODEL_NAMES = ["fdanet", "radiounet", "radiogan", "radiovit"]

# ============================================================================
#  模型缓存
# ============================================================================

_model_cache: dict = {}

def _load_model(model_name: str):
    if model_name in _model_cache:
        return _model_cache[model_name]
    ckpt_path = CKPT_DIR / f"{model_name}_best.pth"
    if not ckpt_path.exists():
        raise FileNotFoundError(f"找不到检查点：{ckpt_path}")
    model = build_model(model_name, in_channels=5).to(DEVICE)
    ckpt  = torch.load(ckpt_path, map_location=DEVICE, weights_only=True)
    state = ckpt.get("model_state", ckpt)
    model.load_state_dict(state)
    model.eval()
    _model_cache[model_name] = model
    print(f"[App] 已加载模型 {model_name}  (device={DEVICE})")
    return model

# ============================================================================
#  工具函数
# ============================================================================

def _file_to_pil(file_storage) -> Image.Image:
    return Image.open(file_storage.stream)

def _to_tensor(pil_img: Image.Image) -> torch.Tensor:
    arr = np.array(pil_img.convert("L").resize((IMG_SIZE, IMG_SIZE)), dtype=np.float32) / 255.0
    return torch.from_numpy(arr).unsqueeze(0)  # [1, H, W]

def _colorize(pred_np: np.ndarray) -> str:
    """预测图 → jet 热力图 → base64 PNG 字符串（供 HTML <img> 显示）"""
    import matplotlib.cm as cm
    colored = (cm.jet(pred_np)[:, :, :3] * 255).astype(np.uint8)
    img = Image.fromarray(colored)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()

def _grade(mae_db: float) -> str:
    if mae_db < 3:   return "优秀"
    if mae_db < 6:   return "良好"
    if mae_db < 10:  return "一般"
    return "较差"

# ============================================================================
#  Flask 应用
# ============================================================================

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024  # 最大 32 MB

@app.route("/")
def index():
    return render_template("index.html", model_names=MODEL_NAMES)

@app.route("/predict", methods=["POST"])
def predict():
    model_name = request.form.get("model_name", "fdanet")

    # 读取 5 张必填输入图
    keys = ["buildings", "buildings_height", "roads", "antenna_height", "antenna_pos"]
    labels = ["建筑物二值图", "建筑物高度图", "道路图", "基站高度图", "基站位置图"]
    pil_inputs = []
    for k, label in zip(keys, labels):
        f = request.files.get(k)
        if f is None or f.filename == "":
            return jsonify({"error": f"请上传「{label}」"}), 400
        pil_inputs.append(_file_to_pil(f))

    # 加载模型
    try:
        model = _load_model(model_name)
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 400

    # 推理
    inp = torch.stack([_to_tensor(img) for img in pil_inputs], dim=1).to(DEVICE)
    with torch.no_grad():
        pred = model(inp)                              # [1, 1, 256, 256]
    pred_np = pred.squeeze().cpu().numpy().clip(0.0, 1.0)

    # 统计
    pred_dbm = pred_np * (RSRP_MAX - RSRP_MIN) + RSRP_MIN
    result = {
        "model":      model_name,
        "device":     str(DEVICE),
        "rsrp_min":   f"{pred_dbm.min():.1f}",
        "rsrp_max":   f"{pred_dbm.max():.1f}",
        "rsrp_mean":  f"{pred_dbm.mean():.1f}",
        "pred_img":   _colorize(pred_np),
        "mae_db":     None,
        "rmse":       None,
        "grade":      None,
    }

    # 可选：与真实地图对比
    gt_file = request.files.get("gt_map")
    if gt_file and gt_file.filename != "":
        gt_pil = _file_to_pil(gt_file)
        gt_np  = np.array(gt_pil.convert("L").resize((IMG_SIZE, IMG_SIZE)), dtype=np.float32) / 255.0
        gt_dbm = gt_np * (RSRP_MAX - RSRP_MIN) + RSRP_MIN
        mae_db = float(np.mean(np.abs(pred_dbm - gt_dbm)))
        rmse   = math.sqrt(float(np.mean((pred_np - gt_np) ** 2)))
        result["mae_db"] = f"{mae_db:.2f}"
        result["rmse"]   = f"{rmse:.4f}"
        result["grade"]  = _grade(mae_db)
        result["gt_img"] = _colorize(gt_np)

    return jsonify(result)


if __name__ == "__main__":
    print(f"[App] 设备：{DEVICE}  |  检查点目录：{CKPT_DIR}")
    app.run(host="0.0.0.0", port=5000, debug=False)
