"""
losses.py  —  复合损失函数
===========================
实现三部分加权的复合损失：

  L_total = α · L_pixel  +  β · L_freq  +  γ · L_grad

  L_pixel  : L1 损失（像素域，保证整体精度）
  L_freq   : 傅里叶幅度谱 L1 损失（约束高频能量分布）
  L_grad   : GMSD 梯度幅度相似性偏差（优化边缘锐利度）

另外提供 GANLoss（对抗损失）供 RadioGAN 使用。
"""

from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================================
#  L_pixel：L1 像素损失
# ============================================================================

class PixelLoss(nn.Module):
    def __init__(self):
        super().__init__()
        self.l1 = nn.L1Loss()

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return self.l1(pred, target)


# ============================================================================
#  L_freq：傅里叶幅度谱损失
# ============================================================================

class FrequencyLoss(nn.Module):
    """
    约束预测图与真实图在 2D-FFT 幅度谱上的 L1 距离。
    使用对数幅度（log(1 + A)）以平衡低频主导效应。
    """

    def __init__(self, log_scale: bool = True):
        super().__init__()
        self.log_scale = log_scale
        self.l1 = nn.L1Loss()

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # pred, target: [B, 1, H, W]
        # rfft2 不支持 float16/bfloat16，统一升到 float32 再做 FFT
        pred_fp32   = pred.float()
        target_fp32 = target.float()

        pred_fft   = torch.fft.rfft2(pred_fp32,   norm="ortho")
        target_fft = torch.fft.rfft2(target_fp32, norm="ortho")

        pred_amp   = pred_fft.abs()
        target_amp = target_fft.abs()

        if self.log_scale:
            pred_amp   = torch.log1p(pred_amp)
            target_amp = torch.log1p(target_amp)

        return self.l1(pred_amp, target_amp)


# ============================================================================
#  L_grad：GMSD 梯度幅度相似性偏差
# ============================================================================

class GradientLoss(nn.Module):
    """
    梯度幅度相似性偏差（GMSD）损失。

    GMSD 公式（每像素相似性图）：
        GMS(i,j) = (2 · |∇P| · |∇T| + c) / (|∇P|² + |∇T|² + c)

    损失 = 预测图与真实图 GMS 图的标准差（偏差越大说明边缘质量越差）
    为便于梯度反传，此处使用 L1(GMS, 1) 近似，值越小边缘越匹配。
    """

    def __init__(self, c: float = 0.0026):
        super().__init__()
        self.c = c
        # Prewitt 算子
        prewitt_x = torch.tensor(
            [[-1., 0., 1.], [-1., 0., 1.], [-1., 0., 1.]], dtype=torch.float32
        ).reshape(1, 1, 3, 3) / 3.0
        prewitt_y = torch.tensor(
            [[-1., -1., -1.], [0., 0., 0.], [1., 1., 1.]], dtype=torch.float32
        ).reshape(1, 1, 3, 3) / 3.0
        self.register_buffer("prewitt_x", prewitt_x)
        self.register_buffer("prewitt_y", prewitt_y)

    def _gradient_magnitude(self, x: torch.Tensor) -> torch.Tensor:
        """计算输入 [B,1,H,W] 的梯度幅度图（始终在 float32 上计算）"""
        # prewitt buffer 已注册在 CPU float32；同步到 x 的 device 和 float32
        # 用 float32 计算避免 AMP 下 half 精度卷积的数值问题
        weight_x = self.prewitt_x.to(device=x.device)   # 保持 float32，只迁移设备
        weight_y = self.prewitt_y.to(device=x.device)
        x_fp32 = x.float()                              # 升到 float32
        gx = F.conv2d(x_fp32, weight_x, padding=1)
        gy = F.conv2d(x_fp32, weight_y, padding=1)
        return torch.sqrt(gx ** 2 + gy ** 2 + 1e-8)

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        gp = self._gradient_magnitude(pred)
        gt = self._gradient_magnitude(target)
        c  = self.c

        # 每像素 GMS（越接近 1 越好）
        gms = (2.0 * gp * gt + c) / (gp ** 2 + gt ** 2 + c)

        # 损失：使 GMS 尽量接近 1
        return F.l1_loss(gms, torch.ones_like(gms))


# ============================================================================
#  复合损失（主损失）
# ============================================================================

class CompositeLoss(nn.Module):
    """
    L_total = alpha * L_pixel + beta * L_freq + gamma * L_grad

    默认权重经验值：
        alpha = 1.0  （L1 像素损失，主导项）
        beta  = 0.1  （频率损失，约束全局频谱）
        gamma = 0.5  （梯度/边缘损失，增强边缘清晰度）
    """

    def __init__(
        self,
        alpha: float = 1.0,
        beta:  float = 0.1,
        gamma: float = 0.5,
        log_freq: bool = True,
    ):
        super().__init__()
        self.alpha = alpha
        self.beta  = beta
        self.gamma = gamma

        self.pixel_loss = PixelLoss()
        self.freq_loss  = FrequencyLoss(log_scale=log_freq)
        self.grad_loss  = GradientLoss()

    def forward(
        self, pred: torch.Tensor, target: torch.Tensor
    ) -> Tuple[torch.Tensor, dict]:
        """
        Returns
        -------
        total_loss : scalar tensor
        loss_dict  : {'pixel', 'freq', 'grad', 'total'}
        """
        lp = self.pixel_loss(pred, target)
        lf = self.freq_loss(pred, target)
        lg = self.grad_loss(pred, target)

        total = self.alpha * lp + self.beta * lf + self.gamma * lg

        return total, {
            "pixel": lp,
            "freq":  lf,
            "grad":  lg,
            "total": total,
        }


# ============================================================================
#  GAN 对抗损失（RadioGAN 专用）
# ============================================================================

class GANLoss(nn.Module):
    """
    Least-Squares GAN（LSGAN）损失，训练稳定性优于原始 BCE-GAN。
    """

    def __init__(self):
        super().__init__()
        self.mse = nn.MSELoss()

    def discriminator_loss(
        self,
        real_logits: torch.Tensor,
        fake_logits: torch.Tensor,
    ) -> torch.Tensor:
        """判别器损失"""
        real_target = torch.ones_like(real_logits)
        fake_target = torch.zeros_like(fake_logits)
        return 0.5 * (self.mse(real_logits, real_target) +
                      self.mse(fake_logits, fake_target))

    def generator_loss(self, fake_logits: torch.Tensor) -> torch.Tensor:
        """生成器对抗损失（让 D 认为生成图是真的）"""
        return self.mse(fake_logits, torch.ones_like(fake_logits))

    def forward(self, fake_logits: torch.Tensor) -> torch.Tensor:
        """等同于 generator_loss，便于统一调用"""
        return self.generator_loss(fake_logits)


class RadioGANLoss(nn.Module):
    """
    RadioGAN 总损失 = λ_adv * L_adv + λ_rec * L_pixel + λ_freq * L_freq + λ_grad * L_grad
    """

    def __init__(
        self,
        lambda_adv:  float = 0.01,
        lambda_rec:  float = 1.0,
        lambda_freq: float = 0.1,
        lambda_grad: float = 0.5,
    ):
        super().__init__()
        self.lambda_adv  = lambda_adv
        self.lambda_rec  = lambda_rec
        self.lambda_freq = lambda_freq
        self.lambda_grad = lambda_grad

        self.adv_loss   = GANLoss()
        self.pixel_loss = PixelLoss()
        self.freq_loss  = FrequencyLoss()
        self.grad_loss  = GradientLoss()

    def generator_total_loss(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        fake_logits: torch.Tensor,
    ) -> Tuple[torch.Tensor, dict]:
        l_adv  = self.adv_loss(fake_logits)
        l_rec  = self.pixel_loss(pred, target)
        l_freq = self.freq_loss(pred, target)
        l_grad = self.grad_loss(pred, target)

        total = (self.lambda_adv  * l_adv  +
                 self.lambda_rec  * l_rec  +
                 self.lambda_freq * l_freq +
                 self.lambda_grad * l_grad)

        return total, {
            "adv":   l_adv,
            "pixel": l_rec,
            "freq":  l_freq,
            "grad":  l_grad,
            "total": total,
        }
