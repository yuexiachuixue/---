"""
dataset.py  —  Radio Map Estimation Dataset
=============================================
数据集加载模块，负责将 sjj/ 目录下的五类图像拼合为网络输入，
并将对应的 gain 图像（信号增益图）作为标签。

目录结构（均为 256×256 PNG）：
  sjj/antennas/          {scene}_{ant}.png   —— 基站位置图
  sjj/antennasWHeight/   {scene}_{ant}.png   —— 基站高度图
  sjj/buildings_complete/{scene}.png         —— 建筑物二值图
  sjj/buildingsWHeight/  {scene}.png         —— 建筑物高度图
  sjj/roads/             {scene}.png         —— 道路图
  sjj/gain/              {scene}_{ant}.png   —— 信号增益（Ground-Truth）

输入张量（5 通道，归一化到 [0,1]）：
  ch0  buildings_complete
  ch1  buildingsWHeight
  ch2  roads
  ch3  antennasWHeight
  ch4  antennas (位置图)

目标张量（1 通道，归一化到 [0,1]）：
  gain/{scene}_{ant}.png

速度设计（全量预加载）：
  __init__ 阶段把所有样本的 5 通道输入和 1 通道 target 全部读入内存，
  拼成两个大 tensor：
      self._inputs  : FloatTensor [N, 5, 256, 256]
      self._targets : FloatTensor [N, 1, 256, 256]
  __getitem__ 只做一次 tensor 索引，零磁盘 I/O、零 numpy 操作、零 PIL 调用。
  GPU 喂数速度由内存带宽决定，彻底消除 OneDrive / 磁盘 I/O 瓶颈。
"""

import random
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader


# ────────────────────────────────────────────────────────────────────────────
# 辅助：读取 PNG → float32 numpy [0, 1]
# ────────────────────────────────────────────────────────────────────────────
def _load_gray(path: str) -> np.ndarray:
    img = Image.open(path).convert("L")
    return np.array(img, dtype=np.float32) / 255.0   # (H, W)


# ────────────────────────────────────────────────────────────────────────────
# 数据集类（全量预加载）
# ────────────────────────────────────────────────────────────────────────────
class RadioMapDataset(Dataset):
    """
    全量预加载版本：__init__ 阶段一次性把所有图像读入内存，
    __getitem__ 只做 tensor 索引，零磁盘 I/O。

    内存估算（256×256 float32）：
      每个样本 = (5+1) 通道 × 256 × 256 × 4 bytes ≈ 1.5 MB
      1000 个样本 ≈ 1.5 GB，16GB 内存可轻松容纳。
    """

    def __init__(
        self,
        data_root: str,
        scene_ids: Optional[list] = None,
        augment: bool = False,
    ):
        self.augment = augment  # 保留标记，但实际 flip 移到 GPU batch 级别
        data_root = Path(data_root)

        dir_ant  = data_root / "antennas"
        dir_antH = data_root / "antennasWHeight"
        dir_bld  = data_root / "buildings_complete"
        dir_bldH = data_root / "buildingsWHeight"
        dir_road = data_root / "roads"
        dir_gain = data_root / "gain"

        # ── 解析场景列表 ─────────────────────────────────────────────
        all_scenes = sorted({int(p.stem) for p in dir_bld.glob("*.png")})
        if scene_ids is not None:
            all_scenes = [s for s in all_scenes if s in set(scene_ids)]

        # ── 构建样本列表 (scene, ant) ────────────────────────────────
        samples: list = []
        for scene in all_scenes:
            for p in sorted(dir_ant.glob(f"{scene}_*.png"),
                            key=lambda p: int(p.stem.split("_")[1])):
                samples.append((scene, int(p.stem.split("_")[1])))

        self._samples = samples
        n = len(samples)
        print(f"[Dataset] scenes={len(all_scenes)}, samples={n}，开始全量预加载...", flush=True)

        # ── 场景级图像缓存（buildings/roads 每个场景只有一张，复用）──
        # 先缓存场景级图像，避免重复读盘
        scene_cache: dict = {}
        for scene in all_scenes:
            scene_cache[scene] = (
                _load_gray(str(dir_bld  / f"{scene}.png")),
                _load_gray(str(dir_bldH / f"{scene}.png")),
                _load_gray(str(dir_road / f"{scene}.png")),
            )

        # ── 预分配大 tensor，逐样本填充 ─────────────────────────────
        inputs  = torch.empty(n, 5, 256, 256, dtype=torch.float32)
        targets = torch.empty(n, 1, 256, 256, dtype=torch.float32)

        for i, (scene, ant) in enumerate(samples):
            bld, bldH, road = scene_cache[scene]
            antH    = _load_gray(str(dir_antH / f"{scene}_{ant}.png"))
            ant_map = _load_gray(str(dir_ant  / f"{scene}_{ant}.png"))
            gain    = np.array(
                Image.open(str(dir_gain / f"{scene}_{ant}.png")).convert("L"),
                dtype=np.float32
            ) / 255.0

            inputs[i, 0] = torch.from_numpy(bld)
            inputs[i, 1] = torch.from_numpy(bldH)
            inputs[i, 2] = torch.from_numpy(road)
            inputs[i, 3] = torch.from_numpy(antH)
            inputs[i, 4] = torch.from_numpy(ant_map)
            targets[i, 0] = torch.from_numpy(gain)

            if (i + 1) % 500 == 0 or (i + 1) == n:
                print(f"  预加载进度: {i+1}/{n}", flush=True)

        self._inputs  = inputs   # [N, 5, 256, 256]
        self._targets = targets  # [N, 1, 256, 256]

        mem_mb = (inputs.nbytes + targets.nbytes) / 1024**2
        print(f"[Dataset] 预加载完成，占用内存 {mem_mb:.0f} MB", flush=True)

    def __len__(self):
        return len(self._samples)

    def __getitem__(self, idx):
        # 直接返回 tensor 切片，无拷贝、无增强（增强在 GPU batch 级别做）
        scene, ant = self._samples[idx]
        return self._inputs[idx], self._targets[idx], {"scene": scene, "ant": ant}


# ────────────────────────────────────────────────────────────────────────────
# 数据集分割工具
# ────────────────────────────────────────────────────────────────────────────
def make_splits(
    data_root: str,
    train_ratio: float = 0.7,
    val_ratio:   float = 0.15,
    seed:        int   = 42,
) -> Tuple[list, list, list]:
    """按场景级别划分 train / val / test，避免数据泄露。"""
    data_root = Path(data_root)
    all_scenes = sorted(
        {int(p.stem) for p in (data_root / "buildings_complete").glob("*.png")}
    )
    rng = random.Random(seed)
    rng.shuffle(all_scenes)

    n       = len(all_scenes)
    n_train = int(n * train_ratio)
    n_val   = int(n * val_ratio)

    train_ids = all_scenes[:n_train]
    val_ids   = all_scenes[n_train : n_train + n_val]
    test_ids  = all_scenes[n_train + n_val :]

    print(f"[Split] train={len(train_ids)} val={len(val_ids)} test={len(test_ids)} scenes")
    return train_ids, val_ids, test_ids


def build_dataloaders(
    data_root: str,
    batch_size: int = 32,
    val_batch_size: int = 64,
    num_workers: int = 0,
    prefetch_factor: int = 2,
    persistent_workers: bool = False,
    train_ratio: float = 0.7,
    val_ratio:   float = 0.15,
    seed:        int   = 42,
    max_scenes: Optional[int] = None,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    构建 train / val / test DataLoader。

    全量预加载后数据已在内存中，num_workers=0 最优：
    - 无需多进程读盘，spawn worker 反而会序列化整个缓存（极慢）
    - pin_memory=True 让 CPU→GPU DMA 传输更快
    """
    train_ids, val_ids, test_ids = make_splits(
        data_root, train_ratio, val_ratio, seed
    )

    if max_scenes is not None and max_scenes > 0:
        all_ids = train_ids + val_ids + test_ids
        all_ids = all_ids[:max_scenes]
        n = len(all_ids)
        n_train = max(1, int(n * train_ratio))
        n_val   = max(1, int(n * val_ratio))
        train_ids = all_ids[:n_train]
        val_ids   = all_ids[n_train:n_train + n_val]
        test_ids  = all_ids[n_train + n_val:] or all_ids[-1:]
        print(f"[Smoke] 限制场景数: train={len(train_ids)} val={len(val_ids)} test={len(test_ids)}")

    train_ds = RadioMapDataset(data_root, scene_ids=train_ids, augment=True)
    val_ds   = RadioMapDataset(data_root, scene_ids=val_ids,   augment=False)
    test_ds  = RadioMapDataset(data_root, scene_ids=test_ids,  augment=False)

    # 全量预加载后数据在主进程内存，num_workers 必须为 0
    train_loader = DataLoader(
        train_ds, shuffle=True,
        batch_size=batch_size,
        num_workers=0,
        pin_memory=True,
        drop_last=True,
    )
    val_loader = DataLoader(
        val_ds, shuffle=False,
        batch_size=val_batch_size,
        num_workers=0,
        pin_memory=True,
        drop_last=False,
    )
    test_loader = DataLoader(
        test_ds, shuffle=False,
        batch_size=val_batch_size,
        num_workers=0,
        pin_memory=True,
        drop_last=False,
    )

    return train_loader, val_loader, test_loader
