"""
main.py  —  无线电地图估计主入口
===================================
使用方式（命令行）：

  # 训练单个模型（默认 FDANet）
  python main.py --mode train --model fdanet

  # 训练全部四个模型并对比
  python main.py --mode compare
  
  # 小数据集冒烟测试（快速验证流程正确性）
  python main.py --mode compare --smoke

  # 仅评估（加载已有检查点）
  python main.py --mode eval --model fdanet

  # 可视化预测结果
  python main.py --mode visualize --model fdanet

支持的模型名：fdanet | radiounet | radiogan | radiovit
"""

import os
import sys
import argparse
import logging
import json
import random
from pathlib import Path

import torch
import numpy as np

# ── 项目内模块 ───────────────────────────────────────────────────────────────
from dataset import build_dataloaders
from models  import build_model, MODEL_REGISTRY
from train   import Trainer, GANTrainer
from evaluate import (
    compare_all_models,
    print_comparison_table,
    save_visual_comparison,
    evaluate_rsrp,
)


# ============================================================================
#  日志配置
# ============================================================================

def setup_logger(log_file: str = "radio_map.log"):
    fmt = "[%(asctime)s %(levelname)s] %(message)s"
    logging.basicConfig(
        level=logging.INFO,
        format=fmt,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, mode="a", encoding="utf-8"),
        ],
    )
    log = logging.getLogger(__name__)
    # 检查监控依赖
    try:
        import tqdm        # noqa: F401
    except ImportError:
        log.warning("[Monitor] tqdm 未安装，进度条不可用。运行: pip install tqdm")
    try:
        import matplotlib  # noqa: F401
    except ImportError:
        log.warning("[Monitor] matplotlib 未安装，曲线图不可用。运行: pip install matplotlib")
    return log


# ============================================================================
#  可复现性
# ============================================================================

def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        # benchmark=True：让 cuDNN 自动选择最快卷积算法（固定输入尺寸时收益显著）
        torch.backends.cudnn.benchmark = True
        torch.backends.cudnn.deterministic = False


# ============================================================================
#  进程 & GPU 优先级提升
# ============================================================================

def boost_priority():
    """
    将当前训练进程提升为系统最高优先级，减少其他应用抢占 CPU/GPU 资源。

    Windows：
      - 进程优先级设为 HIGH_PRIORITY（需管理员权限可升至 REALTIME）
      - CUDA 计算优先级设为最高（相对其他 CUDA 进程优先调度）
    """
    log = logging.getLogger(__name__)

    # ── CPU 进程优先级 ───────────────────────────────────────────────
    try:
        import psutil, os  # type: ignore[import]
        p = psutil.Process(os.getpid())
        p.nice(psutil.REALTIME_PRIORITY)
        log.info("[Priority] 进程 CPU 优先级已提升至 REALTIME")
    except ImportError:
        # psutil 未安装，回退到 Windows API
        try:
            import ctypes, os
            # HIGH_PRIORITY_CLASS = 0x80；REALTIME = 0x100（需管理员）
            handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, os.getpid())
            ctypes.windll.kernel32.SetPriorityClass(handle, 0x80)   # HIGH
            log.info("[Priority] 进程 CPU 优先级已提升至 HIGH（via WinAPI）")
        except Exception as e:
            log.warning(f"[Priority] CPU 优先级提升失败: {e}")
    except Exception as e:
        log.warning(f"[Priority] CPU 优先级提升失败（需管理员权限）: {e}")

    # ── CUDA 计算优先级 ──────────────────────────────────────────────
    if torch.cuda.is_available():
        try:
            _, hi = torch.cuda.Stream.priority_range()
            high_priority_stream = torch.cuda.Stream(priority=hi)
            torch.cuda.set_stream(high_priority_stream)
            log.info(f"[Priority] CUDA stream 优先级已设为最高 ({hi})")
        except Exception as e:
            log.warning(f"[Priority] CUDA 优先级设置失败: {e}")


# ============================================================================
#  默认配置
# ============================================================================

DEFAULT_CONFIG = {
    # 路径 —— checkpoints 放到本地磁盘，避免 OneDrive 同步拖慢写入
    "data_root":       r"C:\Users\yuexiaochuixue\sjj",
    "save_dir":        r"C:\Users\yuexiaochuixue\checkpoints",

    # 数据集分割
    "train_ratio":    0.70,
    "val_ratio":      0.15,
    "seed":           42,
    "max_scenes":     100,   # None = 使用全部场景；设为整数可限制加载数量（调试用）

    # DataLoader —— 全量预加载后数据在主进程内存，num_workers 必须为 0
    "batch_size":     16,    # 从 32 调到 64：GPU 利用率低的核心原因是 batch 太小
    "val_batch_size": 32,    # 验证无梯度，但 UNet skip connection 占显存大，不能太大
    "num_workers":    0,     # 预加载数据在主进程内存，spawn worker 会序列化整个缓存（极慢）
    "prefetch_factor": 2,
    "persistent_workers": False,  # num_workers=0 时此项无效

    # 训练
    "epochs":         20,
    "lr":             1e-4,
    "weight_decay":   1e-4,
    "amp":            True,
    "scheduler":      "cosine",
    "warmup_ratio":   0.05,
    "grad_accum_steps": 1,
    "use_compile":    False,
    "channels_last":  True,

    # 损失权重
    "loss_alpha":     1.0,
    "loss_beta":      0.1,
    "loss_gamma":     0.5,

    # GAN 专用
    "lr_g":           2e-4,
    "lr_d":           2e-4,
    "gan_lambda_adv": 0.01,
    "gan_lambda_rec": 1.0,
    "gan_lambda_freq":0.1,
    "gan_lambda_grad":0.5,

    # 保存
    "save_interval":  20,

    # 早停
    "early_stopping": True,
    "es_patience":    5,
    "es_min_delta":   1e-4,
}


# ============================================================================
#  主流程函数
# ============================================================================

def train_model(model_name: str, config: dict, device: torch.device, logger):
    """训练单个模型并返回测试指标。"""
    logger.info(f"{'='*60}")
    logger.info(f"  Training: {model_name.upper()}")
    logger.info(f"{'='*60}")

    try:
        # 数据（预加载阶段也需要捕获 Ctrl+C，否则中断后无清理）
        train_loader, val_loader, test_loader = build_dataloaders(
            data_root=config["data_root"],
            batch_size=config["batch_size"],
            val_batch_size=config.get("val_batch_size", config["batch_size"] * 2),
            num_workers=config["num_workers"],
            prefetch_factor=config.get("prefetch_factor", 2),
            persistent_workers=config.get("persistent_workers", True),
            train_ratio=config["train_ratio"],
            val_ratio=config["val_ratio"],
            seed=config["seed"],
            max_scenes=config.get("max_scenes"),
        )
    except KeyboardInterrupt:
        logger.info("\n[train_model] 预加载阶段收到中断信号，已取消。")
        raise  # 继续向上传播，让 compare_mode / main 感知到中断

    # 模型
    model = build_model(model_name, in_channels=5)

    # ── channels_last：NHWC 内存格式（卷积密集型模型在 NVIDIA 上快 10-20%）──
    if config.get("channels_last", True) and device.type == "cuda":
        model = model.to(memory_format=torch.channels_last)
        logger.info("  [Speed] channels_last memory format enabled")

    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(f"Model '{model_name}' | params: {n_params/1e6:.2f}M")

    # ── torch.compile（PyTorch≥2.0）首 epoch 有编译开销，后续每步快 20-40% ──
    # Windows 上 Triton 不可用时自动回退到 eager 模式，不崩溃
    if config.get("use_compile", True) and hasattr(torch, "compile"):
        try:
            # 先用一个 dummy 前向传播触发编译，捕获 TritonMissing 等异常
            import torch._dynamo as _dynamo
            _dynamo.reset()
            compiled = torch.compile(model, mode="reduce-overhead")
            # 用小 tensor 做一次试运行，确认编译链路完整
            _test = torch.zeros(1, 5, 64, 64, device=device)
            with torch.no_grad():
                compiled(_test)
            del _test
            model = compiled
            logger.info("  [Speed] torch.compile(mode='reduce-overhead') enabled ✓")
        except Exception as e:
            # TritonMissing / Windows 不支持等情况，静默跳过
            logger.info(f"  [Speed] torch.compile unavailable ({type(e).__name__}), "
                        f"falling back to eager mode (no speed loss for correctness)")

    # 选择训练器
    config["model_name"] = model_name
    if model_name == "radiogan":
        trainer = GANTrainer(model, config, device)
    else:
        trainer = Trainer(model, config, device)

    history, test_metrics = trainer.train(train_loader, val_loader, test_loader)
    return test_metrics


def eval_model(model_name: str, config: dict, device: torch.device, logger,
               test_loader=None):
    """从检查点加载模型并在测试集评估。test_loader 可由外部传入以避免重复预加载。"""
    ckpt_path = Path(config["save_dir"]) / f"{model_name}_best.pth"
    if not ckpt_path.exists():
        logger.error(f"Checkpoint not found: {ckpt_path}")
        return {}

    model = build_model(model_name, in_channels=5).to(device)
    ckpt  = torch.load(ckpt_path, map_location=device)
    state = ckpt["model_state"] if "model_state" in ckpt else ckpt
    model.load_state_dict(state)
    model.eval()

    if test_loader is None:
        _, _, test_loader = build_dataloaders(
            data_root=config["data_root"],
            batch_size=config["batch_size"],
            val_batch_size=config.get("val_batch_size", config["batch_size"] * 2),
            num_workers=config["num_workers"],
            prefetch_factor=config.get("prefetch_factor", 2),
            persistent_workers=config.get("persistent_workers", True),
            train_ratio=config["train_ratio"],
            val_ratio=config["val_ratio"],
            seed=config["seed"],
            max_scenes=config.get("max_scenes"),
        )

    from torch.amp import autocast
    metrics_list = []
    with torch.no_grad():
        for inp, target, _ in test_loader:
            inp    = inp.to(device)
            target = target.to(device)
            with autocast(device_type="cuda", enabled=(config["amp"] and device.type == "cuda")):
                pred = model(inp)
            metrics_list.append(evaluate_rsrp(pred, target))

    keys = metrics_list[0].keys()
    avg = {k: sum(m[k] for m in metrics_list) / len(metrics_list) for k in keys}

    logger.info(f"[Eval] {model_name}: " + " | ".join(f"{k}={v:.4f}" for k, v in avg.items()))
    return avg


def _is_valid_checkpoint(ckpt_path: Path, rmse_threshold: float = 0.45) -> bool:
    """
    判断一个 best checkpoint 是否是"真正训练过"的有效权重。
    标准：
      1. 文件存在
      2. best_rmse < threshold（随机模型 RMSE ≈ 0.49）

    注意：best.pth 保存的是验证集历史最优 epoch 的权重，其 epoch 字段
    必然 <= total_epochs，不能用"epoch 是否到达终点"来判断有效性，
    否则会把正常训练完的模型误判为无效并删除。
    """
    if not ckpt_path.exists():
        return False
    try:
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        if not isinstance(ckpt, dict):
            # 纯 state_dict（旧格式）：无法判断质量，视为无效，重新训练
            return False
        best_rmse = ckpt.get("best_rmse", float("inf"))
        if best_rmse >= rmse_threshold:
            return False
        return True
    except Exception:
        return False


def compare_mode(config: dict, device: torch.device, logger):
    """
    依次训练所有四个模型，最后输出对比表格。
    只有 checkpoint 质量达标（RMSE < 0.45）时才跳过训练。
    所有模型就绪后统一建一次 DataLoader 做最终评估，避免重复预加载。
    """
    all_metrics = {}
    save_dir = Path(config["save_dir"])

    # ── 第一阶段：训练所有需要训练的模型 ──────────────────────────────
    for model_name in ["fdanet", "radiounet", "radiogan", "radiovit"]:
        ckpt_path    = save_dir / f"{model_name}_best.pth"
        resume_path  = save_dir / f"{model_name}_resume.pth"

        # resume.pth 存在 → 上次训练被中断，必须继续训练，不管 best.pth 的 RMSE 多好
        has_resume   = resume_path.exists()
        # best.pth 质量达标 且 没有未完成的 resume 断点 → 真正训练完毕，可安全跳过
        already_done = _is_valid_checkpoint(ckpt_path) and not has_resume

        if already_done:
            logger.info(f"[Compare] '{model_name}' 已有有效 checkpoint，跳过训练。")
        else:
            if has_resume:
                logger.info(f"[Compare] '{model_name}' 存在未完成的断点，继续训练...")
            elif ckpt_path.exists():
                logger.info(f"[Compare] '{model_name}' 的 checkpoint 无效（随机权重），重新训练...")
                ckpt_path.unlink()   # 删除无效 checkpoint，避免混淆
            else:
                logger.info(f"[Compare] '{model_name}' 尚未训练，开始训练...")

            interrupted = False
            try:
                m = train_model(model_name, config, device, logger)
            except KeyboardInterrupt:
                logger.info(f"\n[Compare] 训练 '{model_name}' 时收到中断信号，已暂停。")
                logger.info(f"[Compare] 断点已保存，下次运行将从当前模型的中断处继续。")
                interrupted = True
                m = None

            if m:
                # train_model 内部已做测试集评估，直接复用结果
                all_metrics[model_name] = m
            if interrupted:
                # 中断后退出训练阶段；第二阶段仍会对已有 checkpoint 做评估
                logger.info("[Compare] 中断退出，已训练完的模型将在下方统一评估。")
                break

    # ── 第二阶段：统一建一次 DataLoader，对已有 checkpoint 做评估 ────
    models_needing_eval = [
        name for name in ["fdanet", "radiounet", "radiogan", "radiovit"]
        if name not in all_metrics
    ]
    if models_needing_eval:
        logger.info("[Compare] 统一预加载测试集，对已有 checkpoint 进行评估...")
        try:
            _, _, test_loader = build_dataloaders(
                data_root=config["data_root"],
                batch_size=config.get("val_batch_size", config["batch_size"] * 2),
                val_batch_size=config.get("val_batch_size", config["batch_size"] * 2),
                num_workers=config["num_workers"],
                prefetch_factor=config.get("prefetch_factor", 2),
                persistent_workers=config.get("persistent_workers", True),
                train_ratio=config["train_ratio"],
                val_ratio=config["val_ratio"],
                seed=config["seed"],
                max_scenes=config.get("max_scenes"),
            )
        except KeyboardInterrupt:
            logger.info("\n[compare_mode] 预加载阶段收到中断信号，已取消。")
            return all_metrics

        for model_name in models_needing_eval:
            m = eval_model(model_name, config, device, logger,
                           test_loader=test_loader)
            all_metrics[model_name] = m

    logger.info("\n" + "=" * 60)
    logger.info("  FINAL COMPARISON TABLE")
    logger.info("=" * 60)
    table = print_comparison_table(all_metrics)

    # 保存 JSON
    result_file = save_dir / "comparison_results.json"
    with open(result_file, "w", encoding="utf-8") as f:
        json.dump(all_metrics, f, indent=2, ensure_ascii=False)
    logger.info(f"Results saved to {result_file}")

    return all_metrics


def visualize_mode(model_name: str, config: dict, device: torch.device, logger):
    """加载模型，生成可视化对比图。"""
    ckpt_path = Path(config["save_dir"]) / f"{model_name}_best.pth"
    model = build_model(model_name, in_channels=5).to(device)
    if ckpt_path.exists():
        ckpt  = torch.load(ckpt_path, map_location=device)
        state = ckpt["model_state"] if "model_state" in ckpt else ckpt
        model.load_state_dict(state)
        logger.info(f"Loaded checkpoint: {ckpt_path}")
    else:
        logger.warning(f"No checkpoint at {ckpt_path}, using random weights.")

    model.eval()
    _, _, test_loader = build_dataloaders(
        data_root=config["data_root"],
        batch_size=config.get("val_batch_size", 32),
        val_batch_size=config.get("val_batch_size", 32),
        num_workers=config["num_workers"],
        prefetch_factor=config.get("prefetch_factor", 2),
        persistent_workers=config.get("persistent_workers", True),
        train_ratio=config["train_ratio"],
        val_ratio=config["val_ratio"],
        seed=config["seed"],
        max_scenes=config.get("max_scenes"),
    )

    inp, target, _ = next(iter(test_loader))
    inp    = inp.to(device)
    target = target.to(device)

    with torch.no_grad():
        pred = model(inp)

    out_path = str(Path(config["save_dir"]) / f"{model_name}_visualization.png")
    save_visual_comparison(inp.cpu(), pred.cpu(), target.cpu(), out_path, n_samples=4)


# ============================================================================
#  命令行入口
# ============================================================================

def parse_args():
    parser = argparse.ArgumentParser(
        description="Radio Map Estimation — FDA-UNet & Baselines"
    )
    parser.add_argument(
        "--mode", type=str, default="train",
        choices=["train", "eval", "compare", "visualize"],
        help="运行模式：train | eval | compare | visualize",
    )
    parser.add_argument(
        "--model", type=str, default="fdanet",
        choices=list(MODEL_REGISTRY.keys()),
        help="模型名称（train/eval/visualize 时有效）",
    )
    parser.add_argument(
        "--data_root", type=str, default=None,
        help="数据集根目录（覆盖默认配置）",
    )
    parser.add_argument(
        "--save_dir", type=str, default=None,
        help="检查点保存目录（覆盖默认配置）",
    )
    parser.add_argument("--epochs",    type=int,   default=None)
    parser.add_argument("--batch_size",type=int,   default=None)
    parser.add_argument("--lr",        type=float, default=None)
    parser.add_argument("--seed",      type=int,   default=None)
    parser.add_argument("--no_amp",    action="store_true",
                        help="禁用自动混合精度")
    parser.add_argument("--no_early_stopping", action="store_true",
                        help="禁用早停机制")
    parser.add_argument("--es_patience", type=int, default=None,
                        help="早停耐心值：连续多少 epoch 无改善则停止（默认 15）")
    parser.add_argument("--max_scenes", type=int, default=None,
                        help="限制训练使用的场景总数（0 或不传 = 使用全部场景）。"
                             "例：--max_scenes 100 只取前 100 个场景，"
                             "按 train/val/test 比例自动分配。"
                             "smoke 模式会自动设为 100，此参数可在正式训练中手动指定")
    parser.add_argument("--smoke",     action="store_true",
                        help="小数据集冒烟测试：100 场景 / 5 epoch / batch=16，快速验证流程正确性")
    return parser.parse_args()


def main():
    args   = parse_args()
    logger = setup_logger()
    config = DEFAULT_CONFIG.copy()

    # 覆盖命令行参数
    if args.data_root:   config["data_root"]   = args.data_root
    if args.save_dir:    config["save_dir"]    = args.save_dir
    if args.epochs:      config["epochs"]      = args.epochs
    if args.batch_size:  config["batch_size"]  = args.batch_size
    if args.lr:          config["lr"]          = args.lr
    if args.seed:        config["seed"]        = args.seed
    if args.no_amp:      config["amp"]         = False
    if args.no_early_stopping: config["early_stopping"] = False
    if args.es_patience: config["es_patience"] = args.es_patience
    # --max_scenes：正式训练也可限制场景数；smoke 会在下方再次覆盖为 30
    if args.max_scenes is not None and args.max_scenes > 0:
        config["max_scenes"] = args.max_scenes
        logger.info(f"[Config] 场景数限制：{args.max_scenes} 个（按 train/val/test 比例分配）")
    if args.smoke:
        # ── 冒烟测试：目的是快速验证流程正确性，不追求收敛 ──────────────
        config["max_scenes"]      = 20     # 100 场景 → 训练集 ~70 场景，足够 GPU 持续工作
        config["epochs"]          = 5        # 只跑 5 epoch，够看到 loss 下降即可
        config["batch_size"]      = 16       # 更小 batch → 更多步/epoch，GPU 不空转
        config["val_batch_size"]  = 32
        config["early_stopping"]  = False    # smoke epoch 太少，禁用早停避免提前中断
        config["save_interval"]   = 999      # smoke 期间不做周期性保存，减少写盘
        config["save_dir"]        = str(Path(config["save_dir"]) / "smoke")
        config["use_compile"]     = False    # 跳过 torch.compile 编译开销（首次编译 >30s）
        logger.info(
            "[Smoke] 冒烟测试模式：100 场景 / 5 epoch / batch=16 / 早停已禁用 / compile已禁用"
        )

    # 设备选择
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Device: {device}")
    if device.type == "cuda":
        logger.info(f"GPU: {torch.cuda.get_device_name(0)} | "
                    f"VRAM: {torch.cuda.get_device_properties(0).total_memory/1e9:.1f}GB")

    # 可复现性
    set_seed(config["seed"])

    # 提升进程和 GPU 优先级（压制其他应用抢占）
    boost_priority()

    # 创建保存目录
    Path(config["save_dir"]).mkdir(parents=True, exist_ok=True)

    # 保存本次运行配置
    cfg_path = Path(config["save_dir"]) / "config.json"
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    logger.info(f"Config saved to {cfg_path}")

    # ── 分发到各模式 ──────────────────────────────────────────────────────────
    if args.mode == "train":
        metrics = train_model(args.model, config, device, logger)
        if metrics:
            logger.info("Final Test Metrics:")
            for k, v in metrics.items():
                logger.info(f"  {k}: {v:.4f}")

    elif args.mode == "eval":
        eval_model(args.model, config, device, logger)

    elif args.mode == "compare":
        compare_mode(config, device, logger)

    elif args.mode == "visualize":
        visualize_mode(args.model, config, device, logger)

    logger.info("Done.")


if __name__ == "__main__":
    main()
