"""
evaluate.py  —  评估指标模块
==============================
提供以下指标：

单批次/单张图像指标（evaluate_rsrp）：
  - RMSE（均方根误差，归一化域 [0,1]）
  - MAE（平均绝对误差，归一化域）
  - RSRP_MAE_dB（RSRP 误差，转换到 dBm 域后的 MAE，核心指标）
  - PSNR（峰值信噪比）
  - SSIM（结构相似性，轻量近似版本）

全数据集对比评估（compare_all_models）：
  - 在 test_loader 上对所有模型批量评估并输出汇总表格
"""

import math
from typing import Dict

import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================================
#  物理转换：归一化值 → RSRP (dBm)
# ============================================================================
# 数据集中像素值代表信号增益，归一化后 [0,1] 对应某个 dBm 范围。
# 根据 RadioUNet 等论文惯例，常见范围为 [-150, 0] dBm（路径损耗含阴影）。
# 此处设 RSRP_MIN = -150 dBm, RSRP_MAX = 0 dBm。

RSRP_MIN_DBM = -150.0
RSRP_MAX_DBM =    0.0


def norm_to_dbm(x_norm: torch.Tensor) -> torch.Tensor:
    """将 [0,1] 归一化值线性映射回 dBm 值域。"""
    return x_norm * (RSRP_MAX_DBM - RSRP_MIN_DBM) + RSRP_MIN_DBM


# ============================================================================
#  基础指标函数
# ============================================================================

def _rmse(pred: torch.Tensor, target: torch.Tensor) -> float:
    return math.sqrt(F.mse_loss(pred, target).item())


def _mae(pred: torch.Tensor, target: torch.Tensor) -> float:
    return F.l1_loss(pred, target).item()


def _psnr(pred: torch.Tensor, target: torch.Tensor, max_val: float = 1.0) -> float:
    mse = F.mse_loss(pred, target).item()
    if mse < 1e-10:
        return 100.0
    return 10.0 * math.log10(max_val ** 2 / mse)


def _ssim_approx(
    pred: torch.Tensor,
    target: torch.Tensor,
    window_size: int = 11,
    C1: float = 0.01 ** 2,
    C2: float = 0.03 ** 2,
) -> float:
    """
    轻量 SSIM：用平均池化近似局部均值/方差，避免引入额外依赖。
    pred, target: [B, 1, H, W]
    """
    pad = window_size // 2
    pool = lambda x: F.avg_pool2d(x, window_size, stride=1, padding=pad)

    mu1 = pool(pred)
    mu2 = pool(target)
    mu1_sq = mu1 ** 2
    mu2_sq = mu2 ** 2
    mu1_mu2 = mu1 * mu2

    sigma1_sq = pool(pred ** 2) - mu1_sq
    sigma2_sq = pool(target ** 2) - mu2_sq
    sigma12   = pool(pred * target) - mu1_mu2

    ssim_map = (
        (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
    ) / (
        (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
    )
    return ssim_map.mean().item()


# ============================================================================
#  主评估函数
# ============================================================================

@torch.no_grad()
def evaluate_rsrp(
    pred: torch.Tensor,
    target: torch.Tensor,
) -> Dict[str, float]:
    """
    计算一个批次的所有评估指标。

    Parameters
    ----------
    pred   : 预测地图  [B, 1, H, W]，值域 [0, 1]
    target : 真实地图  [B, 1, H, W]，值域 [0, 1]

    Returns
    -------
    dict with keys: 'rmse', 'mae', 'rsrp_mae_db', 'psnr', 'ssim'
    """
    pred   = pred.detach().clamp(0.0, 1.0)
    target = target.detach().clamp(0.0, 1.0)

    # 归一化域指标
    rmse_val = _rmse(pred, target)
    mae_val  = _mae(pred, target)
    psnr_val = _psnr(pred, target)
    ssim_val = _ssim_approx(pred, target)

    # RSRP 误差（dBm 域）
    pred_dbm   = norm_to_dbm(pred)
    target_dbm = norm_to_dbm(target)
    rsrp_mae_db = _mae(pred_dbm, target_dbm)  # 单位 dB

    return {
        "rmse":        rmse_val,
        "mae":         mae_val,
        "rsrp_mae_db": rsrp_mae_db,   # 关键指标，单位 dB
        "psnr":        psnr_val,
        "ssim":        ssim_val,
    }


# ============================================================================
#  全模型对比评估
# ============================================================================

@torch.no_grad()
def compare_all_models(
    models_dict: Dict[str, nn.Module],
    test_loader,
    device: torch.device,
    amp: bool = True,
) -> Dict[str, Dict[str, float]]:
    """
    在 test_loader 上对多个模型逐一评估，返回汇总字典。

    Parameters
    ----------
    models_dict : {'fdanet': model1, 'radiounet': model2, ...}
    test_loader : DataLoader
    device      : torch.device

    Returns
    -------
    results : {'model_name': {'rmse': ..., 'mae': ..., ...}, ...}
    """
    from torch.amp import autocast

    results: Dict[str, Dict[str, float]] = {}

    for model_name, model in models_dict.items():
        model.eval()
        model.to(device)

        metrics_accum: Dict[str, float] = {}
        n_batches = 0

        for inp, target, _ in test_loader:
            inp    = inp.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)

            with autocast(device_type="cuda", enabled=(amp and device.type == "cuda")):
                # RadioGAN 推理时走 generator
                if hasattr(model, "generator"):
                    pred = model.generator(inp)
                else:
                    pred = model(inp)

            batch_metrics = evaluate_rsrp(pred, target)

            for k, v in batch_metrics.items():
                metrics_accum[k] = metrics_accum.get(k, 0.0) + v
            n_batches += 1

        avg_metrics = {k: v / n_batches for k, v in metrics_accum.items()}
        results[model_name] = avg_metrics

    return results


def print_comparison_table(results: Dict[str, Dict[str, float]]) -> str:
    """将对比结果格式化为美观的表格字符串并打印。"""
    header_keys = ["rmse", "mae", "rsrp_mae_db", "psnr", "ssim"]
    header_labels = {
        "rmse":        "RMSE↓",
        "mae":         "MAE↓",
        "rsrp_mae_db": "RSRP-MAE(dB)↓",
        "psnr":        "PSNR↑(dB)",
        "ssim":        "SSIM↑",
    }

    col_widths = {"model": 14}
    for k in header_keys:
        col_widths[k] = len(header_labels[k]) + 2

    # 表头
    header = f"{'Model':<{col_widths['model']}}"
    for k in header_keys:
        header += f"  {header_labels[k]:>{col_widths[k]}}"
    sep = "─" * len(header)

    lines = [sep, header, sep]

    for model_name, metrics in results.items():
        row = f"{model_name:<{col_widths['model']}}"
        for k in header_keys:
            v = metrics.get(k, float("nan"))
            fmt = f"{v:.4f}" if k != "psnr" else f"{v:.2f}"
            row += f"  {fmt:>{col_widths[k]}}"
        lines.append(row)

    lines.append(sep)
    table = "\n".join(lines)
    print(table)
    return table


# ============================================================================
#  可视化工具（保存预测图对比）
# ============================================================================

def save_visual_comparison(
    inp: torch.Tensor,
    pred: torch.Tensor,
    target: torch.Tensor,
    save_path: str,
    n_samples: int = 4,
):
    """
    保存 n_samples 组 [输入/建筑|预测|真值] 对比图。
    需要 matplotlib。
    """
    try:
        import matplotlib.pyplot as plt
        import matplotlib.gridspec as gridspec
        import numpy as np
    except ImportError:
        print("[Warning] matplotlib not found, skipping visualization.")
        return

    n = min(n_samples, inp.size(0))
    fig, axes = plt.subplots(n, 3, figsize=(12, 4 * n))
    if n == 1:
        axes = axes[np.newaxis, :]

    for i in range(n):
        # 建筑物通道（ch0）作为环境背景
        env = inp[i, 0].cpu().numpy()
        pr  = pred[i, 0].cpu().numpy()
        gt  = target[i, 0].cpu().numpy()

        # 转为 dBm 显示
        def to_db(x):
            return x * (RSRP_MAX_DBM - RSRP_MIN_DBM) + RSRP_MIN_DBM

        pr_db = to_db(pr)
        gt_db = to_db(gt)

        axes[i, 0].imshow(env, cmap="gray")
        axes[i, 0].set_title("Environment (Buildings)")
        axes[i, 0].axis("off")

        im1 = axes[i, 1].imshow(pr_db, cmap="jet", vmin=RSRP_MIN_DBM, vmax=RSRP_MAX_DBM)
        axes[i, 1].set_title("Predicted RSRP (dBm)")
        axes[i, 1].axis("off")
        plt.colorbar(im1, ax=axes[i, 1], fraction=0.046, pad=0.04)

        im2 = axes[i, 2].imshow(gt_db, cmap="jet", vmin=RSRP_MIN_DBM, vmax=RSRP_MAX_DBM)
        axes[i, 2].set_title("Ground-Truth RSRP (dBm)")
        axes[i, 2].axis("off")
        plt.colorbar(im2, ax=axes[i, 2], fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.savefig(save_path, dpi=120, bbox_inches="tight")
    plt.close()
    print(f"[Visualization] Saved to {save_path}")
