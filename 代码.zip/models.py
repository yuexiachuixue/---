"""
models.py  —  Radio Map Estimation Models
==========================================
包含四个模型：

1. FDANet         ← 主模型：编码器-解码器 + 傅里叶域注意力（FDA）+ 物理嵌入
2. RadioUNet      ← 对比基线：CNN-based U-Net
3. RadioGAN       ← 对比基线：GAN-based（生成器 + 判别器）
4. RadioViT       ← 对比基线：标准 Vision Transformer（仅空间注意力）

所有模型：
  - 输入：[B, 5, 256, 256]  (5 通道环境图)
  - 输出：[B, 1, 256, 256]  (预测无线电地图，值域 [0,1])

物理嵌入模块（PhysicsEncoder）说明：
  - 从第 4 通道（基站高度图）和第 5 通道（基站位置图）自动推导基站位置
  - 基于自由空间路径损耗（FSPL）公式生成归一化先验地图
  - 先验地图经轻量 CNN 提取物理特征，在编码器各层以残差方式融合
  - 无需额外标注，先验地图完全由输入推导，训练/推理接口不变
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================================
#  物理先验模块
# ============================================================================

class PhysicsEncoder(nn.Module):
    """
    物理先验编码器：基于自由空间路径损耗（FSPL）生成先验传播地图，
    并将其编码为多尺度特征，在 FDANet 编码器各层以残差方式融合。

    物理原理（自由空间路径损耗）：
        PL(d) = 20·log10(4π·d·f / c)   [dB]
    归一化到 [0,1] 之后作为软先验（不强制精确，由网络自适应校正）。

    输入约定（来自 5 通道中的第 4、5 通道）：
        ch4（索引 3）：基站高度图  —— 归一化高度，峰值处为基站位置
        ch5（索引 4）：基站位置图  —— 二值/软掩码，亮点为基站

    先验地图生成：
        1. 用 ch5（基站位置图）的最亮像素重心确定基站 (cx, cy)
        2. 计算每个像素到基站的欧氏距离 d（像素单位）
        3. FSPL ∝ log(d+1)，归一化后得到 prior_map ∈ [0,1]
           （距离越远先验信号越弱）
        4. 将 prior_map 与基站高度（天线高度修正）相乘得到最终先验

    融合方式：
        先验地图 → 轻量多尺度 CNN → {P1, P2, P3, P4}（4 个尺度特征）
        分别残差加到 FDANet enc1~enc4 的输出上（维度对齐后）
    """

    # 各编码器尺度对应的输出通道（与 FDANet base_ch=64 保持一致）
    _ENC_CHS = [64, 128, 256, 512]   # enc1~enc4

    def __init__(self, base_ch: int = 64, img_size: int = 256):
        super().__init__()
        self.img_size = img_size

        # 先验地图初始特征提取（输入 2 通道：prior_map + antenna_height）
        self.prior_stem = nn.Sequential(
            nn.Conv2d(2, base_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(base_ch),
            nn.ReLU(inplace=True),
        )

        # 多尺度下采样（共 3 次，生成 4 个尺度）
        ch = base_ch
        self.scale_layers = nn.ModuleList()
        for out_ch in self._ENC_CHS[1:]:   # 128, 256, 512
            self.scale_layers.append(nn.Sequential(
                nn.MaxPool2d(2),
                nn.Conv2d(ch, out_ch, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_ch),
                nn.ReLU(inplace=True),
            ))
            ch = out_ch

        # 门控融合：每个尺度学一个 [0,1] 权重，控制物理先验的注入强度
        self.gates = nn.ModuleList([
            nn.Sequential(
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
                nn.Linear(c, 1),
                nn.Sigmoid(),
            )
            for c in self._ENC_CHS
        ])

    # ── 先验地图生成（纯张量运算，可 batch 并行） ─────────────────────────
    @staticmethod
    def _build_prior(antenna_pos: torch.Tensor,
                     antenna_height: torch.Tensor) -> torch.Tensor:
        """
        antenna_pos:    [B, 1, H, W]，归一化基站位置图
        antenna_height: [B, 1, H, W]，归一化基站高度图
        返回 prior_map: [B, 1, H, W]，路径损耗先验（1=强信号区，0=弱信号区）
        """
        B, _, H, W = antenna_pos.shape
        device = antenna_pos.device

        # ── 基站重心（软加权均值，比硬 argmax 更平滑，梯度友好） ──────────
        pos_flat = antenna_pos.view(B, H * W)           # [B, N]
        # 归一化权重（softmax 保证和为1）
        w = torch.softmax(pos_flat * 10.0, dim=1)       # 温度=10，突出峰值
        idx = torch.arange(H * W, device=device).float()
        cx  = (w * (idx % W)).sum(dim=1)                # [B], 列坐标
        cy  = (w * (idx // W)).sum(dim=1)               # [B], 行坐标

        # ── 距离图 ─────────────────────────────────────────────────────────
        yy = torch.arange(H, device=device).float().view(1, H, 1).expand(B, H, W)
        xx = torch.arange(W, device=device).float().view(1, 1, W).expand(B, H, W)
        cx = cx.view(B, 1, 1)
        cy = cy.view(B, 1, 1)
        dist = torch.sqrt((xx - cx) ** 2 + (yy - cy) ** 2 + 1e-6)  # [B, H, W]

        # ── FSPL 先验（log-distance 模型，路径指数 n≈2 → log(d)） ─────────
        pl_norm = torch.log1p(dist) / math.log(math.sqrt(H ** 2 + W ** 2) + 1)
        prior   = 1.0 - pl_norm.clamp(0.0, 1.0)        # 翻转：近=强=1

        # ── 天线高度修正（高天线覆盖更远，先验整体提升） ──────────────────
        # antenna_height: [B, 1, H, W] → 全图平均高度标量 [B, 1, 1]
        ant_h = antenna_height.squeeze(1).mean(dim=(-1, -2))    # [B]
        ant_h = ant_h.view(B, 1, 1)                             # [B, 1, 1]
        prior = prior * (0.5 + 0.5 * ant_h)            # 天线越高先验衰减越慢

        return prior.unsqueeze(1)                       # [B, 1, H, W]

    def forward(self, x: torch.Tensor):
        """
        x: [B, 5, H, W]  原始 5 通道输入
        返回 List[Tensor]，长度 4，分别对应 enc1~enc4 尺度的物理特征
        """
        ant_pos    = x[:, 4:5, :, :]   # ch5: 基站位置图
        ant_height = x[:, 3:4, :, :]   # ch4: 基站高度图

        # 1. 生成归一化物理先验地图
        prior = self._build_prior(ant_pos, ant_height)   # [B, 1, H, W]

        # 2. 拼接先验 + 基站高度 → 双通道输入
        stem_in = torch.cat([prior, ant_height], dim=1)  # [B, 2, H, W]

        # 3. 提取多尺度物理特征
        feats = []
        p = self.prior_stem(stem_in)    # [B, 64, H, W]
        feats.append(p)
        for layer in self.scale_layers:
            p = layer(p)
            feats.append(p)             # [B, 128/256/512, H/2/H/4/H/8, ...]

        # 4. 门控加权：每个尺度的物理特征乘以自适应权重
        gated = []
        for feat, gate in zip(feats, self.gates):
            g = gate(feat).view(-1, 1, 1, 1)   # [B, 1, 1, 1]
            gated.append(feat * g)
        return gated   # List of [B, C, H', W'] × 4


# ============================================================================
#  通用基础模块
# ============================================================================

class ConvBnRelu(nn.Module):
    """Conv2d → BN → ReLU"""
    def __init__(self, in_ch, out_ch, kernel=3, stride=1, padding=1, bias=False):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel, stride, padding, bias=bias),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class DoubleConv(nn.Module):
    """两层 ConvBnRelu"""
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.block = nn.Sequential(
            ConvBnRelu(in_ch,  out_ch),
            ConvBnRelu(out_ch, out_ch),
        )

    def forward(self, x):
        return self.block(x)


# ============================================================================
#  空间自注意力模块（CBAM 风格，轻量化）
# ============================================================================

class SpatialAttention(nn.Module):
    """通道 + 空间注意力（轻量 CBAM）"""
    def __init__(self, channels, reduction=16):
        super().__init__()
        # 通道注意力
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(channels, channels // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels),
            nn.Sigmoid(),
        )
        # 空间注意力
        self.sa = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x):
        # 通道
        ca_w = self.ca(x).view(x.size(0), x.size(1), 1, 1)
        x = x * ca_w
        # 空间
        avg = x.mean(dim=1, keepdim=True)
        mx, _ = x.max(dim=1, keepdim=True)
        sa_w = self.sa(torch.cat([avg, mx], dim=1))
        return x * sa_w


# ============================================================================
#  傅里叶域注意力模块（FDA）—— 核心创新
# ============================================================================

class FDABlock(nn.Module):
    """
    空-频混合注意力（Spatial-Frequency Dual Attention）

    空间分支：CBAM 风格通道+空间注意力（与分辨率线性相关）
    频域分支：FFT → 通道维度注意力（SE，O(C²/r)，与分辨率无关）→ 频域门控 → iFFT
    两路输出相加后残差连接，兼顾局部空间结构与全局频率特征。
    """

    def __init__(self, channels, num_heads=None):  # num_heads 保留以兼容调用方，内部不再使用
        super().__init__()
        self.channels = channels
        r = max(1, channels // 16)

        # ── 空间分支：CBAM 通道 + 空间注意力 ────────────────────────
        self.spatial_ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(channels, r, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(r, channels, bias=False),
            nn.Sigmoid(),
        )
        self.spatial_sa = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False),
            nn.Sigmoid(),
        )

        # ── 频域分支：仅用幅度谱做通道 SE 注意力 → 门控 ─────────────
        # 去掉 angle()（逐元素 arctan2，开销大），相位信息由 iFFT 自然保留
        # spec_proj: [B, C, H, Wh] → [B, C, H, Wh]
        self.spec_proj = nn.Sequential(
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )
        # 通道维度 SE（全局平均池化，O(C²/r)，与分辨率无关）
        self.freq_se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(channels, r, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(r, channels, bias=False),
            nn.Sigmoid(),
        )
        # 频域门控：将 SE 权重广播到频谱空间维度
        self.freq_gate = nn.Conv2d(channels, channels, 1, bias=False)

        self.out_norm = nn.BatchNorm2d(channels)

    def forward(self, x):
        B, C, H, W = x.shape
        x_orig_dtype = x.dtype

        # ── 空间分支 ─────────────────────────────────────────────
        ca_w = self.spatial_ca(x).view(B, C, 1, 1)
        x_sp = x * ca_w
        avg = x_sp.mean(dim=1, keepdim=True)
        mx, _ = x_sp.max(dim=1, keepdim=True)
        sa_w = self.spatial_sa(torch.cat([avg, mx], dim=1))
        x_spatial = x_sp * sa_w                              # [B, C, H, W]

        # ── 频域分支 ─────────────────────────────────────────────
        x_fp32 = x.float() if x_orig_dtype != torch.float32 else x
        x_fft  = torch.fft.rfft2(x_fp32, norm="ortho")       # [B, C, H, W//2+1] 复数

        amp = x_fft.abs().to(x_orig_dtype)                   # [B, C, H, Wh]，不再计算 angle()

        spec_feat = self.spec_proj(amp)                       # [B, C, H, Wh]

        # 通道 SE：全局平均池化 → MLP → 通道权重
        se_w = self.freq_se(spec_feat).view(B, C, 1, 1)      # [B, C, 1, 1]
        gate = torch.sigmoid(self.freq_gate(spec_feat * se_w))  # [B, C, H, Wh]

        x_fft_out = x_fft * gate.float()
        x_freq = torch.fft.irfft2(x_fft_out, s=(H, W), norm="ortho").to(x_orig_dtype)

        # ── 融合 + 残差 ───────────────────────────────────────────
        return self.out_norm(x_spatial + x_freq + x)


# ============================================================================
#  混合注意力块：SpatialAttention + FDABlock 交错
# ============================================================================

class HybridAttentionBlock(nn.Module):
    """空间注意力 → FDA 的顺序组合（可选）"""
    def __init__(self, channels, num_heads=4, use_fda=True):
        super().__init__()
        self.spatial_attn = SpatialAttention(channels)
        self.fda = FDABlock(channels, num_heads=num_heads) if use_fda else nn.Identity()
        self.use_fda = use_fda

    def forward(self, x):
        x = self.spatial_attn(x)
        if self.use_fda:
            x = self.fda(x)
        return x


# ============================================================================
#  FDANet：编码器-解码器 + 跳跃连接 + 混合注意力
# ============================================================================

class FDANet(nn.Module):
    """
    主模型：对称编码器-解码器结构，在瓶颈及多个解码层
    交错部署 SpatialAttention 和 FDABlock。

    编码器通道：5 → 64 → 128 → 256 → 512
    瓶颈：512 → 1024 （含 FDA）
    解码器：1024 → 512 → 256 → 128 → 64 → 1

    物理嵌入：PhysicsEncoder 从 5 通道输入生成多尺度物理先验特征，
    在编码器各层输出后以残差方式加入（Physics-Residual Fusion）。
    """

    def __init__(self, in_channels=5, base_ch=64, use_physics=True):
        super().__init__()
        self.use_physics = use_physics

        # ── 物理嵌入模块 ──────────────────────────────────────────────
        if use_physics:
            self.physics_enc = PhysicsEncoder(base_ch=base_ch, img_size=256)

        # ── 编码器 ────────────────────────────────────────────────
        self.enc1 = DoubleConv(in_channels, base_ch)           # 256x256
        self.enc2 = DoubleConv(base_ch,     base_ch * 2)       # 128x128
        self.enc3 = DoubleConv(base_ch * 2, base_ch * 4)       # 64x64
        self.enc4 = DoubleConv(base_ch * 4, base_ch * 8)       # 32x32

        self.pool = nn.MaxPool2d(2)

        # ── 编码器端注意力（空间，轻量） ────────────────────────────
        self.attn_enc2 = SpatialAttention(base_ch * 2)
        self.attn_enc3 = SpatialAttention(base_ch * 4)
        self.attn_enc4 = SpatialAttention(base_ch * 8)

        # ── 瓶颈（含 FDA）────────────────────────────────────────
        self.bottleneck = DoubleConv(base_ch * 8, base_ch * 16)  # 16x16
        self.hybrid_bn  = HybridAttentionBlock(base_ch * 16, num_heads=8, use_fda=True)

        # ── 解码器 ────────────────────────────────────────────────
        # 每层：上采样 + 跳跃拼接 + DoubleConv + 混合注意力
        self.up4  = nn.ConvTranspose2d(base_ch * 16, base_ch * 8, 2, stride=2)
        self.dec4 = DoubleConv(base_ch * 16, base_ch * 8)
        self.hab4 = HybridAttentionBlock(base_ch * 8, num_heads=4, use_fda=True)

        self.up3  = nn.ConvTranspose2d(base_ch * 8, base_ch * 4, 2, stride=2)
        self.dec3 = DoubleConv(base_ch * 8, base_ch * 4)
        self.hab3 = HybridAttentionBlock(base_ch * 4, num_heads=4, use_fda=False)

        self.up2  = nn.ConvTranspose2d(base_ch * 4, base_ch * 2, 2, stride=2)
        self.dec2 = DoubleConv(base_ch * 4, base_ch * 2)
        self.hab2 = HybridAttentionBlock(base_ch * 2, num_heads=2, use_fda=False)  # 大分辨率，不用FDA

        self.up1  = nn.ConvTranspose2d(base_ch * 2, base_ch, 2, stride=2)
        self.dec1 = DoubleConv(base_ch * 2, base_ch)
        self.hab1 = SpatialAttention(base_ch)

        # ── 输出头 ────────────────────────────────────────────────
        self.out_conv = nn.Sequential(
            nn.Conv2d(base_ch, 1, kernel_size=1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        # ── 物理先验特征（4 个尺度） ──────────────────────────────
        if self.use_physics:
            phy_feats = self.physics_enc(x)   # [P1, P2, P3, P4]
        else:
            phy_feats = [None] * 4

        # 编码（物理特征以残差方式融合到各层输出）
        e1 = self.enc1(x)                                          # [B, 64,  256, 256]
        if phy_feats[0] is not None:
            e1 = e1 + phy_feats[0]

        e2 = self.attn_enc2(self.enc2(self.pool(e1)))              # [B, 128, 128, 128]
        if phy_feats[1] is not None:
            e2 = e2 + phy_feats[1]

        e3 = self.attn_enc3(self.enc3(self.pool(e2)))              # [B, 256,  64,  64]
        if phy_feats[2] is not None:
            e3 = e3 + phy_feats[2]

        e4 = self.attn_enc4(self.enc4(self.pool(e3)))              # [B, 512,  32,  32]
        if phy_feats[3] is not None:
            e4 = e4 + phy_feats[3]

        # 瓶颈
        bn = self.bottleneck(self.pool(e4))          # [B, 1024, 16, 16]
        bn = self.hybrid_bn(bn)

        # 解码（带跳跃连接）
        d4 = self.up4(bn)                            # [B, 512,  32, 32]
        d4 = self.dec4(torch.cat([d4, e4], dim=1))  # [B, 512,  32, 32]
        d4 = self.hab4(d4)

        d3 = self.up3(d4)                            # [B, 256,  64, 64]
        d3 = self.dec3(torch.cat([d3, e3], dim=1))
        d3 = self.hab3(d3)

        d2 = self.up2(d3)                            # [B, 128, 128, 128]
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d2 = self.hab2(d2)

        d1 = self.up1(d2)                            # [B,  64, 256, 256]
        d1 = self.dec1(torch.cat([d1, e1], dim=1))
        d1 = self.hab1(d1)

        return self.out_conv(d1)                     # [B, 1, 256, 256]


# ============================================================================
#  RadioUNet（对比基线 1）
# ============================================================================

class RadioUNet(nn.Module):
    """
    标准 CNN U-Net 基线，不含任何注意力机制，
    与原始 RadioUNet 论文保持相似的结构。
    """

    def __init__(self, in_channels=5, base_ch=64):
        super().__init__()
        self.pool = nn.MaxPool2d(2)

        self.enc1 = DoubleConv(in_channels, base_ch)
        self.enc2 = DoubleConv(base_ch,     base_ch * 2)
        self.enc3 = DoubleConv(base_ch * 2, base_ch * 4)
        self.enc4 = DoubleConv(base_ch * 4, base_ch * 8)
        self.bn   = DoubleConv(base_ch * 8, base_ch * 16)

        self.up4  = nn.ConvTranspose2d(base_ch * 16, base_ch * 8,  2, stride=2)
        self.dec4 = DoubleConv(base_ch * 16, base_ch * 8)
        self.up3  = nn.ConvTranspose2d(base_ch * 8,  base_ch * 4,  2, stride=2)
        self.dec3 = DoubleConv(base_ch * 8,  base_ch * 4)
        self.up2  = nn.ConvTranspose2d(base_ch * 4,  base_ch * 2,  2, stride=2)
        self.dec2 = DoubleConv(base_ch * 4,  base_ch * 2)
        self.up1  = nn.ConvTranspose2d(base_ch * 2,  base_ch,      2, stride=2)
        self.dec1 = DoubleConv(base_ch * 2,  base_ch)

        self.out  = nn.Sequential(
            nn.Conv2d(base_ch, 1, 1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))
        bn = self.bn(self.pool(e4))

        d4 = self.dec4(torch.cat([self.up4(bn), e4], 1))
        d3 = self.dec3(torch.cat([self.up3(d4), e3], 1))
        d2 = self.dec2(torch.cat([self.up2(d3), e2], 1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], 1))

        return self.out(d1)


# ============================================================================
#  RadioGAN（对比基线 2）
# ============================================================================

class _GANGenerator(nn.Module):
    """U-Net 生成器（RadioGAN 的生成侧）"""

    def __init__(self, in_channels=5, base_ch=64):
        super().__init__()
        # 与 RadioUNet 基本相同，但瓶颈加入 Dropout
        self.pool = nn.MaxPool2d(2)

        self.enc1 = DoubleConv(in_channels, base_ch)
        self.enc2 = DoubleConv(base_ch,     base_ch * 2)
        self.enc3 = DoubleConv(base_ch * 2, base_ch * 4)
        self.enc4 = DoubleConv(base_ch * 4, base_ch * 8)
        self.bn   = nn.Sequential(
            DoubleConv(base_ch * 8, base_ch * 16),
            nn.Dropout2d(0.3),
        )

        self.up4  = nn.ConvTranspose2d(base_ch * 16, base_ch * 8,  2, stride=2)
        self.dec4 = DoubleConv(base_ch * 16, base_ch * 8)
        self.up3  = nn.ConvTranspose2d(base_ch * 8,  base_ch * 4,  2, stride=2)
        self.dec3 = DoubleConv(base_ch * 8,  base_ch * 4)
        self.up2  = nn.ConvTranspose2d(base_ch * 4,  base_ch * 2,  2, stride=2)
        self.dec2 = DoubleConv(base_ch * 4,  base_ch * 2)
        self.up1  = nn.ConvTranspose2d(base_ch * 2,  base_ch,      2, stride=2)
        self.dec1 = DoubleConv(base_ch * 2,  base_ch)

        self.out  = nn.Sequential(
            nn.Conv2d(base_ch, 1, 1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        e4 = self.enc4(self.pool(e3))
        bn = self.bn(self.pool(e4))

        d4 = self.dec4(torch.cat([self.up4(bn), e4], 1))
        d3 = self.dec3(torch.cat([self.up3(d4), e3], 1))
        d2 = self.dec2(torch.cat([self.up2(d3), e2], 1))
        d1 = self.dec1(torch.cat([self.up1(d2), e1], 1))

        return self.out(d1)


class _GANDiscriminator(nn.Module):
    """PatchGAN 判别器"""

    def __init__(self, in_channels=6):  # 输入 + 预测拼接
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, 64,  4, 2, 1), nn.LeakyReLU(0.2, True),
            nn.Conv2d(64,  128, 4, 2, 1), nn.BatchNorm2d(128), nn.LeakyReLU(0.2, True),
            nn.Conv2d(128, 256, 4, 2, 1), nn.BatchNorm2d(256), nn.LeakyReLU(0.2, True),
            nn.Conv2d(256, 512, 4, 1, 1), nn.BatchNorm2d(512), nn.LeakyReLU(0.2, True),
            nn.Conv2d(512,   1, 4, 1, 1),
        )

    def forward(self, x, y):
        return self.net(torch.cat([x, y], dim=1))


class RadioGAN(nn.Module):
    """
    RadioGAN 包装类：
      - 调用 .generator(x) 得到预测地图
      - .discriminator(x, y) 用于对抗训练
    推理时仅用 generator。
    """

    def __init__(self, in_channels=5, base_ch=64):
        super().__init__()
        self.generator     = _GANGenerator(in_channels, base_ch)
        self.discriminator = _GANDiscriminator(in_channels + 1)

    def forward(self, x):
        """推理接口，与其他模型保持一致"""
        return self.generator(x)


# ============================================================================
#  RadioViT（对比基线 3）—— 标准 ViT，仅空间注意力
# ============================================================================

class _PatchEmbed(nn.Module):
    """图像→Patch Token 嵌入"""

    def __init__(self, img_size=256, patch_size=16, in_ch=5, embed_dim=768):
        super().__init__()
        self.grid_size = img_size // patch_size   # 16
        self.n_patches = self.grid_size ** 2      # 256
        self.proj = nn.Conv2d(in_ch, embed_dim, patch_size, stride=patch_size)

    def forward(self, x):
        x = self.proj(x)                    # [B, D, grid, grid]
        x = x.flatten(2).transpose(1, 2)   # [B, N, D]
        return x                            # 只返回 tokens，不返回 H/W


class _ViTBlock(nn.Module):
    """标准 Transformer Encoder Block"""

    def __init__(self, dim, num_heads, mlp_ratio=4.0, drop=0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn  = nn.MultiheadAttention(dim, num_heads, dropout=drop, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        mlp_dim = int(dim * mlp_ratio)
        self.mlp  = nn.Sequential(
            nn.Linear(dim, mlp_dim), nn.GELU(),
            nn.Dropout(drop),
            nn.Linear(mlp_dim, dim), nn.Dropout(drop),
        )

    def forward(self, x):
        h = self.norm1(x)
        h, _ = self.attn(h, h, h)
        x = x + h
        x = x + self.mlp(self.norm2(x))
        return x


class RadioViT(nn.Module):
    """
    标准 Vision Transformer（仅空间注意力），用于验证 FDA 的优越性。
    架构：PatchEmbed → Transformer Encoder → CNN Decoder
    Patch 大小：16×16，序列长度 256 tokens（16×16 patches from 256×256 image）
    """

    def __init__(
        self,
        in_channels=5,
        img_size=256,
        patch_size=16,
        embed_dim=512,
        depth=8,
        num_heads=8,
        drop=0.1,
    ):
        super().__init__()
        self.patch_embed = _PatchEmbed(img_size, patch_size, in_channels, embed_dim)
        self.grid_size = img_size // patch_size   # 16，用于 reshape
        n_patches = self.grid_size ** 2           # 256

        # 可学习位置编码
        self.pos_embed = nn.Parameter(torch.zeros(1, n_patches, embed_dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        self.blocks = nn.Sequential(
            *[_ViTBlock(embed_dim, num_heads, drop=drop) for _ in range(depth)]
        )
        self.norm = nn.LayerNorm(embed_dim)

        # CNN 解码器：将 token 还原为 256×256 地图
        # tokens: [B, 256, D] → reshape → [B, D, 16, 16] → 上采样
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(embed_dim, 256, 2, stride=2),   # 32×32
            nn.BatchNorm2d(256), nn.ReLU(True),
            nn.ConvTranspose2d(256, 128, 2, stride=2),         # 64×64
            nn.BatchNorm2d(128), nn.ReLU(True),
            nn.ConvTranspose2d(128,  64, 2, stride=2),         # 128×128
            nn.BatchNorm2d(64),  nn.ReLU(True),
            nn.ConvTranspose2d( 64,  32, 2, stride=2),         # 256×256
            nn.BatchNorm2d(32),  nn.ReLU(True),
            nn.Conv2d(32, 1, 1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        tokens = self.patch_embed(x)           # [B, N, D]，N=256
        tokens = tokens + self.pos_embed
        for blk in self.blocks:
            tokens = blk(tokens)
        tokens = self.norm(tokens)             # [B, N, D]

        B, N, D = tokens.shape
        G = self.grid_size                     # 16，静态常量，compile 可安全追踪
        feat = tokens.transpose(1, 2).reshape(B, D, G, G)  # [B, D, 16, 16]
        return self.decoder(feat)              # [B, 1, 256, 256]


# ============================================================================
#  模型注册表（供 main.py 统一调用）
# ============================================================================

MODEL_REGISTRY = {
    "fdanet":    FDANet,
    "radiounet": RadioUNet,
    "radiogan":  RadioGAN,
    "radiovit":  RadioViT,
}


def build_model(name: str, **kwargs) -> nn.Module:
    name = name.lower()
    if name not in MODEL_REGISTRY:
        raise ValueError(f"Unknown model '{name}'. Available: {list(MODEL_REGISTRY)}")
    return MODEL_REGISTRY[name](**kwargs)


if __name__ == "__main__":
    # 快速冒烟测试
    x = torch.randn(2, 5, 256, 256)
    for name, cls in MODEL_REGISTRY.items():
        model = cls()
        with torch.no_grad():
            out = model(x)
        print(f"[{name:12s}]  input={tuple(x.shape)}  output={tuple(out.shape)}")
