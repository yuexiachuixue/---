"""
train.py  —  训练循环
======================
支持两种训练模式：
  1. 普通监督训练（FDANet / RadioUNet / RadioViT）
  2. GAN 对抗训练（RadioGAN）

使用方式（由 main.py 调用）：
  trainer = Trainer(model, config)
  trainer.train(train_loader, val_loader)
"""

import inspect
import time
import math
import logging
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.amp import GradScaler, autocast

from losses import CompositeLoss, RadioGANLoss
from evaluate import evaluate_rsrp
from monitor import TrainingMonitor


def build_grad_scaler(enabled: bool):
    """兼容旧版和新版 PyTorch 的 GradScaler 初始化参数。"""
    try:
        signature = inspect.signature(GradScaler.__init__)
        if "device_type" in signature.parameters:
            return GradScaler(device_type="cuda", enabled=enabled)
    except (TypeError, ValueError):
        pass
    return GradScaler(enabled=enabled)

logger = logging.getLogger(__name__)


# ============================================================================
#  学习率调度工具
# ============================================================================

def build_scheduler(optimizer, config: dict, steps_per_epoch: int):
    """根据配置构建学习率调度器。"""
    sched_type = config.get("scheduler", "cosine")
    total_steps = config["epochs"] * steps_per_epoch

    if sched_type == "cosine":
        warmup_steps = int(total_steps * config.get("warmup_ratio", 0.05))
        def lr_lambda(step):
            if step < warmup_steps:
                return step / max(1, warmup_steps)
            progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
            return 0.5 * (1.0 + math.cos(math.pi * progress))
        return optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    elif sched_type == "step":
        return optim.lr_scheduler.StepLR(
            optimizer,
            step_size=config.get("step_size", 30),
            gamma=config.get("step_gamma", 0.5),
        )
    elif sched_type == "plateau":
        return optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode="min", factor=0.5, patience=5
        )
    else:
        return None


# ============================================================================
#  普通监督训练器
# ============================================================================

class EarlyStopping:
    """
    早停工具类：监控验证集 RMSE，连续 patience 个 epoch 无改善则触发停止。

    参数
    ----
    patience  : 允许没有改善的最大 epoch 数（默认 5）
    min_delta : 被认为是"改善"的最小变化量（默认 1e-4）
    """

    def __init__(self, patience: int = 5, min_delta: float = 1e-4):
        self.patience   = patience
        self.min_delta  = min_delta
        self.counter    = 0          # 连续未改善计数
        self.best_score = float("inf")
        self.triggered  = False

    def step(self, metric: float) -> bool:
        """
        传入当前 epoch 的监控指标（越小越好，如 RMSE）。
        返回 True 表示应当停止训练。
        """
        # 已经触发过，直接返回，不再累加 counter
        # 避免 counter 超过 patience 后续训时立刻再次触发
        if self.triggered:
            return True
        if metric < self.best_score - self.min_delta:
            self.best_score = metric
            self.counter    = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.triggered = True
        return self.triggered

    def state_dict(self) -> dict:
        return {
            "counter":    self.counter,
            "best_score": self.best_score,
            "triggered":  self.triggered,
        }

    def load_state_dict(self, d: dict):
        self.best_score = d.get("best_score", float("inf"))
        # 续训时 counter 和 triggered 都重置：
        # 若上次是被早停触发而中断的，重新启动训练说明用户有意继续，
        # counter 若原样恢复（>= patience），下一个 epoch 会立刻再次触发早停。
        self.counter   = 0
        self.triggered = False


class Trainer:
    """
    适用于 FDANet / RadioUNet / RadioViT 的监督训练器。
    支持混合精度训练（AMP）和早停（Early Stopping）。
    """

    def __init__(self, model: nn.Module, config: dict, device: torch.device):
        self.model  = model.to(device)
        self.config = config
        self.device = device
        self.model_name = config.get("model_name", "fdanet")

        # channels_last 标记：数据送入前需转换内存格式
        self.channels_last = (
            config.get("channels_last", True) and device.type == "cuda"
        )

        # 梯度累积步数（显存不足时设为 2，等效翻倍 batch）
        self.grad_accum = max(1, config.get("grad_accum_steps", 1))

        # 损失函数
        self.criterion = CompositeLoss(
            alpha=config.get("loss_alpha", 1.0),
            beta=config.get("loss_beta",  0.1),
            gamma=config.get("loss_gamma", 0.5),
        )

        # 优化器
        self.optimizer = optim.AdamW(
            model.parameters(),
            lr=config.get("lr", 1e-4),
            weight_decay=config.get("weight_decay", 1e-4),
        )

        # 混合精度
        self.use_amp = config.get("amp", True) and device.type == "cuda"
        self.scaler = build_grad_scaler(enabled=self.use_amp)

        # 保存目录
        self.save_dir = Path(config.get("save_dir", "checkpoints"))
        self.save_dir.mkdir(parents=True, exist_ok=True)

        self.best_metric = float("inf")
        self.epochs = config.get("epochs", 100)

        # 早停
        self.early_stopping = EarlyStopping(
            patience=config.get("es_patience", 15),
            min_delta=config.get("es_min_delta", 1e-4),
        ) if config.get("early_stopping", True) else None

        # 监控器（每次 train() 调用时初始化，model_name 已在 config 中）
        self.monitor: Optional[TrainingMonitor] = None

    def _train_one_epoch(
        self,
        loader: DataLoader,
        scheduler,
        epoch: int,
    ) -> dict:
        self.model.train()
        # 用 tensor 累积，避免每 batch .item() 触发 GPU 同步
        total_loss = torch.tensor(0.0, device=self.device)
        detail_sum = {
            "pixel": torch.tensor(0.0, device=self.device),
            "freq":  torch.tensor(0.0, device=self.device),
            "grad":  torch.tensor(0.0, device=self.device),
        }
        n_batches = len(loader)

        self.optimizer.zero_grad(set_to_none=True)   # 梯度累积：放在循环外

        # ── 监控：开启本 epoch 进度条 ──────────────────────────────────
        pbar = self.monitor.start_epoch(epoch, n_batches) if self.monitor else None
        # 每 log_interval 个 batch 才做一次 GPU→CPU 同步，减少流水线停顿
        log_interval = max(1, n_batches // 20)
        last_loss_dict_cpu: dict = {}

        completed = 0   # 实际完成的 batch 数，用于中断时计算部分均值
        self._last_train_stats = None   # 中断时也能把部分结果传给外层
        try:
            for batch_idx, (inp, target, _) in enumerate(loader):
                inp    = inp.to(self.device, non_blocking=True)
                target = target.to(self.device, non_blocking=True)

                # GPU batch 级数据增强（比 CPU 逐样本 flip 快 10x+）
                # inp 已在预加载时转为 channels_last，无需再转
                if torch.rand(1).item() > 0.5:
                    inp    = inp.flip(3)
                    target = target.flip(3)
                if torch.rand(1).item() > 0.5:
                    inp    = inp.flip(2)
                    target = target.flip(2)

                with autocast(device_type="cuda", enabled=self.use_amp):
                    pred = self.model(inp)
                    loss, loss_dict = self.criterion(pred, target)
                    # 梯度累积：将损失除以累积步数，保持梯度量级不变
                    loss = loss / self.grad_accum

                self.scaler.scale(loss).backward()

                # 只在累积满 grad_accum 步，或到达最后一个 batch 时更新参数
                is_accum_step = ((batch_idx + 1) % self.grad_accum == 0) or \
                                (batch_idx + 1 == n_batches)
                if is_accum_step:
                    self.scaler.unscale_(self.optimizer)
                    nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)

                    if scheduler is not None and not isinstance(
                        scheduler, optim.lr_scheduler.ReduceLROnPlateau
                    ):
                        scheduler.step()

                total_loss += loss_dict["total"]
                for k in detail_sum:
                    detail_sum[k] += loss_dict[k]
                completed += 1

                # ── 监控：每 log_interval 批次同步一次，减少 GPU→CPU 停顿 ──
                if self.monitor:
                    lr = self.optimizer.param_groups[0]["lr"]
                    if (batch_idx + 1) % log_interval == 0 or (batch_idx + 1) == n_batches:
                        last_loss_dict_cpu = {k: v.item() for k, v in loss_dict.items()}
                    self.monitor.update_batch(pbar, last_loss_dict_cpu, lr, batch_idx)
        finally:
            # 无论正常结束还是 KeyboardInterrupt，都确保进度条被关闭
            if self.monitor:
                self.monitor.close_pbar(pbar)
            # 用实际完成的 batch 数算均值，中断时也能得到有效的部分结果
            if completed > 0:
                denom = completed
                avg = {k: v.item() / denom for k, v in detail_sum.items()}
                avg["total"] = total_loss.item() / denom
                self._last_train_stats = avg   # 传给外层

        return self._last_train_stats

    @torch.no_grad()
    def _validate(self, loader: DataLoader) -> dict:
        self.model.eval()
        metrics_list = []
        for inp, target, _ in loader:
            inp    = inp.to(self.device, non_blocking=True)
            target = target.to(self.device, non_blocking=True)
            # inp 已在预加载时转为 channels_last，无需再转
            with autocast(device_type="cuda", enabled=self.use_amp):
                pred = self.model(inp)
            m = evaluate_rsrp(pred, target)
            metrics_list.append(m)

        # 平均所有批次的指标
        keys = metrics_list[0].keys()
        avg = {k: sum(m[k] for m in metrics_list) / len(metrics_list) for k in keys}
        return avg

    def _save_resume_ckpt(self, epoch: int, scheduler):
        """保存可续训的完整检查点（原子写入，防止中断时产生损坏文件）。"""
        ckpt_path = self.save_dir / f"{self.model_name}_resume.pth"
        tmp_path  = self.save_dir / f"{self.model_name}_resume.tmp"
        payload = {
            "epoch":        epoch,
            "model_state":  self.model.state_dict(),
            "optim_state":  self.optimizer.state_dict(),
            "scaler_state": self.scaler.state_dict(),
            "best_rmse":    self.best_metric,
            "config":       self.config,
        }
        if scheduler is not None:
            payload["sched_state"] = scheduler.state_dict()
        if self.early_stopping is not None:
            payload["es_state"] = self.early_stopping.state_dict()
        # 先写临时文件，写完再原子替换，避免 Ctrl+C 打断产生损坏的断点
        torch.save(payload, tmp_path)
        tmp_path.replace(ckpt_path)
        logger.info(f"  [Resume] 断点已保存 → {ckpt_path}  (epoch {epoch})")

    def train(
        self,
        train_loader: DataLoader,
        val_loader:   DataLoader,
        test_loader:  Optional[DataLoader] = None,
    ):
        steps_per_epoch = len(train_loader)
        scheduler = build_scheduler(self.optimizer, self.config, steps_per_epoch)

        # ── 断点续训：检查 resume checkpoint ──────────────────────────
        start_epoch = 1
        resume_path = self.save_dir / f"{self.model_name}_resume.pth"
        if resume_path.exists():
            logger.info(f"[Trainer] 发现断点文件 {resume_path}，正在恢复...")
            try:
                ckpt = torch.load(resume_path, map_location=self.device, weights_only=False)
                self.model.load_state_dict(ckpt["model_state"])
                self.optimizer.load_state_dict(ckpt["optim_state"])
                self.scaler.load_state_dict(ckpt["scaler_state"])
                self.best_metric = ckpt.get("best_rmse", float("inf"))
                if scheduler is not None and "sched_state" in ckpt:
                    scheduler.load_state_dict(ckpt["sched_state"])
                if self.early_stopping is not None and "es_state" in ckpt:
                    self.early_stopping.load_state_dict(ckpt["es_state"])
                # 兜底同步：若断点中没有 es_state（旧格式），用 best_rmse 初始化基线
                elif self.early_stopping is not None:
                    self.early_stopping.best_score = self.best_metric
                start_epoch = ckpt["epoch"] + 1
                logger.info(f"[Trainer] 从 epoch {start_epoch} 继续训练，best_rmse={self.best_metric:.4f}")
            except Exception as e:
                logger.warning(f"[Trainer] 断点文件损坏（{e}），已删除，将从头开始训练。")
                resume_path.unlink(missing_ok=True)

        logger.info(
            f"[Trainer] '{self.model_name}' | epochs={self.epochs} | "
            f"device={self.device} | AMP={self.use_amp} | "
            f"channels_last={self.channels_last} | "
            f"grad_accum={self.grad_accum} | "
            f"train_bs={train_loader.batch_size} | "
            f"val_bs={val_loader.batch_size}"
        )

        # ── 初始化监控器 ────────────────────────────────────────────────
        self.monitor = TrainingMonitor(
            total_epochs=self.epochs,
            save_dir=self.save_dir,
            model_name=self.model_name,
        )

        history = {"train_loss": [], "val_rmse": [], "val_mae": []}

        epoch = start_epoch - 1
        _interrupted = False
        try:
            for epoch in range(start_epoch, self.epochs + 1):
                t0 = time.time()

                # ── 训练 ──────────────────────────────────────────────
                train_stats = self._train_one_epoch(train_loader, scheduler, epoch)

                # ── 验证 ──────────────────────────────────────────────
                torch.cuda.empty_cache()
                val_metrics = self._validate(val_loader)

                elapsed = time.time() - t0

                # ── 监控：打印 epoch 摘要 ──────────────────────────────
                self.monitor.end_epoch(epoch, train_stats, val_metrics, elapsed)
                self.monitor.append_epoch(epoch, train_stats, val_metrics, elapsed)

                history["train_loss"].append(train_stats["total"])
                history["val_rmse"].append(val_metrics["rmse"])
                history["val_mae"].append(val_metrics["mae"])

                # ReduceLROnPlateau 需要传入监控指标
                if isinstance(scheduler, optim.lr_scheduler.ReduceLROnPlateau):
                    scheduler.step(val_metrics["rmse"])

                # ── 保存最优模型 ───────────────────────────────────────
                if val_metrics["rmse"] < self.best_metric:
                    self.best_metric = val_metrics["rmse"]
                    ckpt_path = self.save_dir / f"{self.model_name}_best.pth"
                    tmp_path  = self.save_dir / f"{self.model_name}_best.tmp"
                    torch.save(
                        {
                            "epoch":        epoch,
                            "model_state":  self.model.state_dict(),
                            "optim_state":  self.optimizer.state_dict(),
                            "best_rmse":    self.best_metric,
                            "config":       self.config,
                        },
                        tmp_path,
                    )
                    tmp_path.replace(ckpt_path)
                    logger.info(f"  ✓ Best model saved → {ckpt_path}")

                # ── 周期性保存 ─────────────────────────────────────────
                save_interval = self.config.get("save_interval", 20)
                if epoch % save_interval == 0:
                    ckpt_path = self.save_dir / f"{self.model_name}_epoch{epoch}.pth"
                    torch.save(self.model.state_dict(), ckpt_path)

                # ── 每 epoch 结束后更新续训断点 ────────────────────────
                self._save_resume_ckpt(epoch, scheduler)

                # ── 早停检查 ───────────────────────────────────────────
                if self.early_stopping is not None:
                    if self.early_stopping.step(val_metrics["rmse"]):
                        logger.info(
                            f"  [EarlyStopping] 验证 RMSE 连续 {self.early_stopping.patience} 个 epoch "
                            f"无改善（当前最优 {self.early_stopping.best_score:.4f}），"
                            f"提前终止训练于 epoch {epoch}。"
                        )
                        break
                    else:
                        logger.info(
                            f"  [EarlyStopping] counter={self.early_stopping.counter}/{self.early_stopping.patience}"
                        )
        except KeyboardInterrupt:
            _interrupted = True
            raise
        finally:
            # 无论正常结束、早停还是 Ctrl+C，都生成曲线图
            self.monitor.finish(history, interrupted=_interrupted)
            # 正常完成/早停时删除续训断点；中断时保留断点供下次续训
            if not _interrupted and resume_path.exists():
                resume_path.unlink()
                logger.info("[Trainer] 训练完成，已删除续训断点文件。")

        # ── 测试集最终评估 ──────────────────────────────────────────
        if test_loader is not None:
            best_ckpt = self.save_dir / f"{self.model_name}_best.pth"
            if not best_ckpt.exists():
                logger.warning("[Trainer] 未找到 best checkpoint，跳过测试集评估。")
                return history, {}
            logger.info("[Trainer] Loading best checkpoint for test evaluation...")
            ckpt = torch.load(best_ckpt, map_location=self.device)
            self.model.load_state_dict(ckpt["model_state"])
            test_metrics = self._validate(test_loader)
            logger.info(
                f"[Test] RMSE={test_metrics['rmse']:.4f} "
                f"MAE={test_metrics['mae']:.4f} "
                f"RSRP_MAE={test_metrics.get('rsrp_mae_db', float('nan')):.2f}dB "
                f"PSNR={test_metrics.get('psnr', float('nan')):.2f}dB "
                f"SSIM={test_metrics.get('ssim', float('nan')):.4f}"
            )
            return history, test_metrics

        return history, {}


# ============================================================================
#  GAN 训练器（RadioGAN 专用）
# ============================================================================

class GANTrainer:
    """
    RadioGAN 对抗训练器：交替更新生成器和判别器。
    """

    def __init__(self, model, config: dict, device: torch.device):
        self.model  = model.to(device)
        self.config = config
        self.device = device

        self.gan_loss = RadioGANLoss(
            lambda_adv=config.get("gan_lambda_adv",  0.01),
            lambda_rec=config.get("gan_lambda_rec",  1.0),
            lambda_freq=config.get("gan_lambda_freq", 0.1),
            lambda_grad=config.get("gan_lambda_grad", 0.5),
        )

        lr_g = config.get("lr_g", 2e-4)
        lr_d = config.get("lr_d", 2e-4)

        self.opt_G = optim.AdamW(
            model.generator.parameters(), lr=lr_g,
            betas=(0.5, 0.999), weight_decay=1e-5
        )
        self.opt_D = optim.AdamW(
            model.discriminator.parameters(), lr=lr_d,
            betas=(0.5, 0.999), weight_decay=1e-5
        )

        self.use_amp = config.get("amp", True) and device.type == "cuda"
        self.scaler_G = build_grad_scaler(enabled=self.use_amp)
        self.scaler_D = build_grad_scaler(enabled=self.use_amp)

        self.save_dir = Path(config.get("save_dir", "checkpoints"))
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.epochs = config.get("epochs", 100)
        self.best_metric = float("inf")
        self.monitor: Optional[TrainingMonitor] = None

        # 早停
        self.early_stopping = EarlyStopping(
            patience=config.get("es_patience", 15),
            min_delta=config.get("es_min_delta", 1e-4),
        ) if config.get("early_stopping", True) else None

    def _train_one_epoch(self, loader: DataLoader, epoch: int) -> dict:
        self.model.train()
        stats = {
            "G_total": torch.tensor(0.0, device=self.device),
            "D_total": torch.tensor(0.0, device=self.device),
            "G_pixel": torch.tensor(0.0, device=self.device),
            "G_adv":   torch.tensor(0.0, device=self.device),
        }
        n = len(loader)
        log_interval = max(1, n // 20)
        last_loss_dict_cpu: dict = {}

        # ── 监控：开启本 epoch 进度条 ──────────────────────────────────
        pbar = self.monitor.start_epoch(epoch, n) if self.monitor else None

        try:
            for batch_idx, (inp, target, _) in enumerate(loader):
                inp    = inp.to(self.device, non_blocking=True)
                target = target.to(self.device, non_blocking=True)

                # ── 更新判别器 D ────────────────────────────────────────
                self.opt_D.zero_grad(set_to_none=True)
                with autocast(device_type="cuda", enabled=self.use_amp):
                    with torch.no_grad():
                        fake = self.model.generator(inp)
                    real_logits = self.model.discriminator(inp, target)
                    fake_logits = self.model.discriminator(inp, fake.detach())
                    d_loss = self.gan_loss.adv_loss.discriminator_loss(real_logits, fake_logits)

                self.scaler_D.scale(d_loss).backward()
                self.scaler_D.unscale_(self.opt_D)
                nn.utils.clip_grad_norm_(self.model.discriminator.parameters(), max_norm=1.0)
                self.scaler_D.step(self.opt_D)
                self.scaler_D.update()

                # ── 更新生成器 G ────────────────────────────────────────
                self.opt_G.zero_grad(set_to_none=True)
                with autocast(device_type="cuda", enabled=self.use_amp):
                    fake = self.model.generator(inp)
                    fake_logits = self.model.discriminator(inp, fake)
                    g_loss, g_dict = self.gan_loss.generator_total_loss(fake, target, fake_logits)

                self.scaler_G.scale(g_loss).backward()
                nn.utils.clip_grad_norm_(self.model.generator.parameters(), 1.0)
                self.scaler_G.step(self.opt_G)
                self.scaler_G.update()

                stats["G_total"] += g_dict["total"]
                stats["D_total"] += d_loss
                stats["G_pixel"] += g_dict["pixel"]
                stats["G_adv"]   += g_dict["adv"]

                # ── 监控：每 log_interval 批次同步一次 ──────────────────
                if self.monitor:
                    lr = self.opt_G.param_groups[0]["lr"]
                    if (batch_idx + 1) % log_interval == 0 or (batch_idx + 1) == n:
                        last_loss_dict_cpu = {
                            "total": g_dict["total"].item(),
                            "pixel": g_dict["pixel"].item(),
                            "adv":   g_dict["adv"].item(),
                            "D":     d_loss.item(),
                        }
                    self.monitor.update_batch(pbar, last_loss_dict_cpu, lr, batch_idx)
        finally:
            # 无论正常结束还是 KeyboardInterrupt，都确保进度条被关闭
            # 否则中断时 tqdm 进度条会残留在终端，导致输出混乱
            if self.monitor:
                self.monitor.close_pbar(pbar)

        return {k: v.item() / n for k, v in stats.items()}

    @torch.no_grad()
    def _validate(self, loader: DataLoader) -> dict:
        self.model.eval()
        metrics_list = []
        for inp, target, _ in loader:
            inp    = inp.to(self.device, non_blocking=True)
            target = target.to(self.device, non_blocking=True)
            pred = self.model.generator(inp)
            metrics_list.append(evaluate_rsrp(pred, target))
        keys = metrics_list[0].keys()
        return {k: sum(m[k] for m in metrics_list) / len(metrics_list) for k in keys}

    def _save_resume_ckpt(self, epoch: int):
        """保存可续训的完整检查点（原子写入，防止中断时产生损坏文件）。"""
        ckpt_path = self.save_dir / "radiogan_resume.pth"
        tmp_path  = self.save_dir / "radiogan_resume.tmp"
        payload = {
            "epoch":         epoch,
            "model_state":   self.model.state_dict(),
            "optG_state":    self.opt_G.state_dict(),
            "optD_state":    self.opt_D.state_dict(),
            "scalerG_state": self.scaler_G.state_dict(),
            "scalerD_state": self.scaler_D.state_dict(),
            "best_rmse":     self.best_metric,
            "config":        self.config,
        }
        if self.early_stopping is not None:
            payload["es_state"] = self.early_stopping.state_dict()
        # 先写临时文件，写完再原子替换，避免 Ctrl+C 打断产生损坏的断点
        torch.save(payload, tmp_path)
        tmp_path.replace(ckpt_path)
        logger.info(f"  [Resume] 断点已保存 → {ckpt_path}  (epoch {epoch})")

    def train(self, train_loader, val_loader, test_loader=None):
        logger.info(f"[GANTrainer] Training RadioGAN for {self.epochs} epochs")
        history = {"G_loss": [], "D_loss": [], "val_rmse": []}

        # ── 断点续训：检查 resume checkpoint ──────────────────────────
        start_epoch = 1
        resume_path = self.save_dir / "radiogan_resume.pth"
        if resume_path.exists():
            logger.info(f"[GANTrainer] 发现断点文件 {resume_path}，正在恢复...")
            try:
                ckpt = torch.load(resume_path, map_location=self.device, weights_only=False)
                self.model.load_state_dict(ckpt["model_state"])
                self.opt_G.load_state_dict(ckpt["optG_state"])
                self.opt_D.load_state_dict(ckpt["optD_state"])
                self.scaler_G.load_state_dict(ckpt["scalerG_state"])
                self.scaler_D.load_state_dict(ckpt["scalerD_state"])
                self.best_metric = ckpt.get("best_rmse", float("inf"))
                if self.early_stopping is not None and "es_state" in ckpt:
                    self.early_stopping.load_state_dict(ckpt["es_state"])
                # 兜底同步：若断点中没有 es_state（旧格式），用 best_rmse 初始化基线
                elif self.early_stopping is not None:
                    self.early_stopping.best_score = self.best_metric
                start_epoch = ckpt["epoch"] + 1
                logger.info(f"[GANTrainer] 从 epoch {start_epoch} 继续训练，best_rmse={self.best_metric:.4f}")
            except Exception as e:
                logger.warning(f"[GANTrainer] 断点文件损坏（{e}），已删除，将从头开始训练。")
                resume_path.unlink(missing_ok=True)

        # ── 初始化监控器 ────────────────────────────────────────────────
        self.monitor = TrainingMonitor(
            total_epochs=self.epochs,
            save_dir=self.save_dir,
            model_name="radiogan",
        )

        epoch = start_epoch - 1
        _interrupted = False
        try:
            for epoch in range(start_epoch, self.epochs + 1):
                t0 = time.time()
                stats = self._train_one_epoch(train_loader, epoch)
                val_m = self._validate(val_loader)
                elapsed = time.time() - t0

                # ── 监控：打印 epoch 摘要（extra 展示 GAN 专用字段）─────────
                train_stats_for_monitor = {"total": stats["G_total"], "G_total": stats["G_total"]}
                self.monitor.end_epoch(
                    epoch, train_stats_for_monitor, val_m, elapsed,
                    extra={"D_loss": stats["D_total"], "G_adv": stats["G_adv"]},
                )
                self.monitor.append_epoch(
                    epoch, train_stats_for_monitor, val_m, elapsed,
                    extra={"D_loss": stats["D_total"]},
                )

                history["G_loss"].append(stats["G_total"])
                history["D_loss"].append(stats["D_total"])
                history["val_rmse"].append(val_m["rmse"])

                if val_m["rmse"] < self.best_metric:
                    self.best_metric = val_m["rmse"]
                    ckpt = self.save_dir / "radiogan_best.pth"
                    tmp  = self.save_dir / "radiogan_best.tmp"
                    torch.save({
                        "epoch":       epoch,
                        "model_state": self.model.state_dict(),
                        "best_rmse":   self.best_metric,
                        "config":      self.config,
                    }, tmp)
                    tmp.replace(ckpt)
                    logger.info(f"  ✓ Best GAN saved → {ckpt}")

                # ── 每 epoch 结束后更新续训断点 ────────────────────────
                self._save_resume_ckpt(epoch)

                # ── 早停检查 ───────────────────────────────────────────
                if self.early_stopping is not None:
                    if self.early_stopping.step(val_m["rmse"]):
                        logger.info(
                            f"  [EarlyStopping] 验证 RMSE 连续 {self.early_stopping.patience} 个 epoch "
                            f"无改善（当前最优 {self.early_stopping.best_score:.4f}），"
                            f"提前终止训练于 epoch {epoch}。"
                        )
                        break
                    else:
                        logger.info(
                            f"  [EarlyStopping] counter={self.early_stopping.counter}/{self.early_stopping.patience}"
                        )
        except KeyboardInterrupt:
            _interrupted = True
            raise
        finally:
            # 无论正常结束、早停还是 Ctrl+C，都生成曲线图
            self.monitor.finish(history, interrupted=_interrupted)
            # 正常完成/早停时删除续训断点；中断时保留断点供下次续训
            if not _interrupted and resume_path.exists():
                resume_path.unlink()
                logger.info("[GANTrainer] 训练完成，已删除续训断点文件。")

        if test_loader:
            ckpt_path = self.save_dir / "radiogan_best.pth"
            if not ckpt_path.exists():
                logger.warning("[GANTrainer] 未找到 best checkpoint，跳过测试集评估。")
                return history, {}
            ckpt_data = torch.load(ckpt_path, map_location=self.device, weights_only=False)
            state = ckpt_data["model_state"] if isinstance(ckpt_data, dict) else ckpt_data
            self.model.load_state_dict(state)
            test_m = self._validate(test_loader)
            logger.info(
                f"[Test] RMSE={test_m['rmse']:.4f} "
                f"RSRP_MAE={test_m.get('rsrp_mae_db', float('nan')):.2f}dB"
            )
            return history, test_m

        return history, {}
